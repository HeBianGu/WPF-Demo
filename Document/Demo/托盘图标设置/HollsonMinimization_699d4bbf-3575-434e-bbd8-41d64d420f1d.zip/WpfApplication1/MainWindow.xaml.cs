﻿using System;
using System.ServiceProcess;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace WpfApplication1
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        WindowState lastWindowState;
        bool shouldClose;

        public MainWindow()
        {
            InitializeComponent();
        }

        // 下载于www.51aspx.com
        //窗口状态
        protected override void OnStateChanged(EventArgs e)
        {
            lastWindowState = WindowState;
        }

        #region 托盘效果
        //关闭窗口时
        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (!shouldClose)
            {
                e.Cancel = true;
                Hide();
            }
        }

        //关于作者
        protected void OnMenuItemAboutClick(object sender, EventArgs e)
        {
            new Window1().Show();
        }

        //双击回复窗口
        private void OnNotificationAreaIconDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                Open();
            }
        }
        // 下载于www.51aspx.com
        //托盘打开按钮
        private void OnMenuItemOpenClick(object sender, EventArgs e)
        {
            Open();
        }

        //打开窗口
        private void Open()
        {
            Show();
            WindowState = lastWindowState;
        }
        // 下载于www.51aspx.com
        //退出
        private void OnMenuItemExitClick(object sender, EventArgs e)
        {
            shouldClose = true;
            Close();
        } 
        #endregion
    }
}