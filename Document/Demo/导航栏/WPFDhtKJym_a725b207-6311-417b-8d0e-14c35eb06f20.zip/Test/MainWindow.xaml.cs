﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CustomControlLibrary;

namespace Test
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        // 下载于www.51aspx.com
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            navigationBarControl.AddNav(new CustomControlLibrary.NavigationBarControlModel { DisplayValue = "A", Key = "A" });
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            navigationBarControl.RemoveNav();
        }

        private void navigationBarControl_NavClick(object sender, RoutedEventArgs e)
        {
            NavClickRoutedEventArgs ncrea = e as NavClickRoutedEventArgs;
            // 下载于www.51aspx.com
            Console.WriteLine(ncrea.Key);
        }
    }
}
