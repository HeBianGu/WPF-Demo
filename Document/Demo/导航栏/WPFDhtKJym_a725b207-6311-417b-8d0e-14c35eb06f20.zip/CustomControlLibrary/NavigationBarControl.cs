﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Collections;

namespace CustomControlLibrary
{
    public class NavigationBarControl:Control
    {
        #region 字段

        public static readonly RoutedEvent NavClickRoutedEvent =
            EventManager.RegisterRoutedEvent("NavClick", RoutingStrategy.Bubble, typeof(EventHandler<NavClickRoutedEventArgs>), typeof(NavigationBarControl));
        //CLR事件包装
        public event RoutedEventHandler NavClick
        {
            add { this.AddHandler(NavClickRoutedEvent, value); }
            remove { this.RemoveHandler(NavClickRoutedEvent, value); }
        }

        #endregion

        #region 属性

        #region 依赖性属性

        public NavigationBarControlModel HomeNav
        {
            get { return (NavigationBarControlModel)GetValue(HomeNavProperty); }
            set { SetValue(HomeNavProperty, value); }
        }
        public static readonly DependencyProperty HomeNavProperty =
            DependencyProperty.Register("HomeNav", typeof(NavigationBarControlModel), typeof(NavigationBarControl), new UIPropertyMetadata((s, e) => { }));


        public ObservableCollection<NavigationBarControlModel> NavList
        {
            get { return (ObservableCollection<NavigationBarControlModel>)GetValue(NavListProperty); }
            set { SetValue(NavListProperty, value); }
        }
        public static readonly DependencyProperty NavListProperty =
            DependencyProperty.Register("NavList", typeof(ObservableCollection<NavigationBarControlModel>), typeof(NavigationBarControl), new UIPropertyMetadata(new ObservableCollection<NavigationBarControlModel>(),(s, e) => {
                
            
            }));

        #endregion

        #endregion

        #region 事件

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
        }

        #endregion
        // 下载于www.51aspx.com

        #region 方法

        static NavigationBarControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(NavigationBarControl), new FrameworkPropertyMetadata(typeof(NavigationBarControl)));
        }

        public NavigationBarControl()
        {
            NavList.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(NavList_CollectionChanged);
        }

        void NavList_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            StackPanel stackPanel_children = base.GetTemplateChild("stackPanel_children") as StackPanel;

            if (stackPanel_children != null)
            {
                stackPanel_children.Children.Clear();

                for (int i = 0; i < NavList.Count; i++)
                {
                    TextBlock textBlock_content = new TextBlock();
                    textBlock_content.Text = NavList[i].DisplayValue;
                    textBlock_content.Tag = NavList[i];                    
                    textBlock_content.Margin = new Thickness(3);
                    stackPanel_children.Children.Add(textBlock_content);

                    if (i !=NavList.Count - 1)
                    {
                        textBlock_content.TextDecorations = TextDecorations.Underline;
                        textBlock_content.MouseLeftButtonDown += new System.Windows.Input.MouseButtonEventHandler(textBlock_content_MouseLeftButtonDown);

                        TextBlock textBlock_bar = new TextBlock();
                        textBlock_bar.Text = ">";
                        textBlock_bar.Margin = new Thickness(3);

                        
                        stackPanel_children.Children.Add(textBlock_bar);
                    }
                    
                }
            }
        }

        void textBlock_content_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            TextBlock textBlock = sender as TextBlock;

            if (textBlock != null && textBlock.Tag != null && textBlock.Tag is NavigationBarControlModel)
            {
                int navIndex = NavList.IndexOf((NavigationBarControlModel)textBlock.Tag);

                int tempIndex = NavList.Count - navIndex - 1;

                for (int i = 0; i < tempIndex; i++)
                {
                    this.RemoveNav();
                }

                NavClickRoutedEventArgs args = new NavClickRoutedEventArgs(NavigationBarControl.NavClickRoutedEvent, this);
                args.Key = ((NavigationBarControlModel)textBlock.Tag).Key;
                
                this.RaiseEvent(args);//UIElement及其派生类 
            }

            
        }


        public void AddNav(NavigationBarControlModel navModel)
        {
            NavList.Add(navModel);
        }

        public void RemoveNav()
        {
            if (NavList.Count != 0)
            {
                NavList.RemoveAt(NavList.Count - 1);
            }
        }

        #endregion

        
    }

    public class NavClickRoutedEventArgs : RoutedEventArgs
    {
        public NavClickRoutedEventArgs(RoutedEvent r, object o)
            : base(r, o)
        { }

        public string Key { get; set; }
    }

    public class NavigationBarControlModel:INotifyPropertyChanged
    {
        #region 字段

        private string _Key = string.Empty;
        private string _DisplayValue = string.Empty;
        private string _SelectValue = string.Empty;

        #endregion

        #region 属性

        public string Key
        {
            get { return _Key; }
            set
            {
                if (_Key != value)
                {
                    _Key = value;
                    this.OnPropertyChanged("Key");
                }
            }
        }

        public string DisplayValue
        {
            get { return _DisplayValue; }
            set
            {
                if (_DisplayValue != value)
                {
                    _DisplayValue = value;
                    this.OnPropertyChanged("DisplayValue");
                }
            }
        }

        public string SelectValue
        {
            get { return _SelectValue; }
            set
            {
                if (_SelectValue != value)
                {
                    _SelectValue = value;
                    this.OnPropertyChanged("SelectValue");
                }
            }
        }

        #endregion

        #region 事件

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
