﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Imageviewer
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private System.Windows.Point origin;
        private System.Windows.Point start;
        Bitmap bitmap;
        public MainWindow()
        {
            InitializeComponent();
            bitmap = new Bitmap(Environment.CurrentDirectory+"\\a.jpg");
        }
        // 下载于www.51aspx.com

        private void Grid_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            ChangImgSize(e.Delta > 0);
        }

        private void image1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (image1.IsMouseCaptured) return;
            image1.CaptureMouse();
            start = e.GetPosition(this);
            origin.X = image1.RenderTransform.Value.OffsetX;
            origin.Y = image1.RenderTransform.Value.OffsetY;
            e.Handled = true;
        }

        private void image1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            image1.ReleaseMouseCapture();
        }

        private void image1_MouseMove(object sender, MouseEventArgs e)
        {
            if (!image1.IsMouseCaptured) return;
            System.Windows.Point point = e.MouseDevice.GetPosition(this);
            Matrix m = image1.RenderTransform.Value;
            m.OffsetX = origin.X + (point.X - start.X);
            m.OffsetY = origin.Y + (point.Y - start.Y);

            image1.RenderTransform = new MatrixTransform(m);
        }

        private void btnUndo_Click(object sender, RoutedEventArgs e)
        {
            if (image1.RenderTransform.Value.Determinant == 1)
            {
                // 放大到原始
                Matrix m = image1.RenderTransform.Value;

                System.Windows.Point p = new System.Windows.Point((image1.ActualWidth) / 2, (image1.ActualHeight) / 2);

                m.ScaleAtPrepend(bitmap.Width / image1.ActualWidth, bitmap.Height / image1.ActualHeight, p.X, p.Y);

                image1.RenderTransform = new MatrixTransform(m);
            }
            else
            {
                image1.RenderTransform = new MatrixTransform(new Matrix(1, 0, 0, 1, 0, 0));
            }
        }

        private void btnBig_Click(object sender, RoutedEventArgs e)
        {
            ChangImgSize(true);
        }
        // 下载于www.51aspx.com
        private void btnSmall_Click(object sender, RoutedEventArgs e)
        {
            ChangImgSize(false);
        }

        private void ChangImgSize(bool big)
        {
            Matrix m = image1.RenderTransform.Value;
            System.Windows.Point p = new System.Windows.Point((image1.ActualWidth) / 2, (image1.ActualHeight) / 2);
            if (big)
            {
                m.ScaleAtPrepend(1.1, 1.1, p.X, p.Y);
            }
            else
            {
                m.ScaleAtPrepend(1 / 1.1, 1 / 1.1, p.X, p.Y);
            }

            image1.RenderTransform = new MatrixTransform(m);
        }

        private void btnleftRevolve_Click(object sender, RoutedEventArgs e)
        {
            bitmap.RotateFlip(System.Drawing.RotateFlipType.Rotate90FlipNone);
            image1.RenderTransform = new MatrixTransform(new Matrix(1, 0, 0, 1, 0, 0));
            image1.Source = new System.Drawing.Bitmap(bitmap).GetImageSourceByBitmap();
        }

        private void btnrightRevolve_Click(object sender, RoutedEventArgs e)
        {
            bitmap.RotateFlip(System.Drawing.RotateFlipType.Rotate270FlipNone);
            image1.RenderTransform = new MatrixTransform(new Matrix(1, 0, 0, 1, 0, 0));
            image1.Source = new System.Drawing.Bitmap(bitmap).GetImageSourceByBitmap();
        }
    }

    public static class ImageSourceHelper
    {
        [DllImport("gdi32.dll", SetLastError = true)]
        private static extern bool DeleteObject(IntPtr hObject);
        // 下载于www.51aspx.com
        /// <summary>
        /// Bitmap转换为ImageSource
        /// </summary>
        /// <param name="bitmap">图片</param>
        /// <returns>ImageSource</returns>
        public static ImageSource GetImageSourceByBitmap(this System.Drawing.Bitmap bitmap)
        {
            IntPtr hBitmap = bitmap.GetHbitmap();
            ImageSource wpfBitmap = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                hBitmap,
                IntPtr.Zero,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());
            if (!DeleteObject(hBitmap))//记得要进行内存释放。否则会有内存不足的报错。
            {
                throw new System.ComponentModel.Win32Exception();
            }
            return wpfBitmap;
        }
    }
}
