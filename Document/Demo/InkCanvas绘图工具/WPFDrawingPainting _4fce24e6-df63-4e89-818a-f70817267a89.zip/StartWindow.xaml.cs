﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace mgen_ink_wpf
{
    /// <summary>
    /// StartWindow.xaml 的交互逻辑
    /// </summary>
    public partial class StartWindow : Window
    {
        public StartWindow()
        {
            InitializeComponent();
        }

        private void sign_MouseEnter(object sender, MouseEventArgs e)
        {
            sign.Opacity = 0.5;
        }

        private void sign_MouseLeave(object sender, MouseEventArgs e)
        {
            sign.Opacity = 1;
        }

        private void sign_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           // this.Hide();
            Signature sign = new Signature();
            sign.ShowDialog();
        }

        private void draw_MouseEnter(object sender, MouseEventArgs e)
        {
            draw.Opacity = 0.5;
        }

        private void draw_MouseLeave(object sender, MouseEventArgs e)
        {
            draw.Opacity =1;
        }
        // 下载于www.51aspx.com
        private void draw_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           // this.Hide();
            MainWindow main = new MainWindow();
            main.ShowDialog();
        }
    }
}
