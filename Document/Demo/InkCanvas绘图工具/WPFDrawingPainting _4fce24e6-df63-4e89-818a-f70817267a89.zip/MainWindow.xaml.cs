﻿namespace mgen_ink_wpf
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using System.Drawing;
    using System.IO;
    using Microsoft.Win32;
    using System.Web;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool flag = false;
        #region Fields
        System.Windows.Controls.Image img;
        MediaPlayer player = new MediaPlayer();
        int num =1;
        InkDrawing inkDrawing;

        #endregion Fields
        // 下载于www.51aspx.com
        #region Constructors

        public MainWindow()
        {
            InitializeComponent();
        }

        #endregion Constructors

        #region Methods


        private void slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (inkDrawing != null)
                inkDrawing.DrawingAttributes.Width = inkDrawing.DrawingAttributes.Height = slider.Value;
        }

        private void New_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Rect rect = new Rect(inkPresenter.RenderSize);
            this.inkPresenter.Strokes.Erase(rect);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            inkDrawing = new InkDrawing(inkPresenter,border);
            inkDrawing.Mode = InkDrawingMode.Draw;
            inkDrawing.SetThickness(slider.Value);
        }

        #endregion Methods

        private void Save_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Rect rect = this.inkPresenter.Strokes.GetBounds();
            if (rect.Height <= 0 || rect.Width <= 0)
            {
                System.Windows.MessageBox.Show("请先画图！");
                return;
            }
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "bmp图片|*.bmp|jpg图片|*.jpg|gif图片|*.gif|png图片|*.png";
            string fileName = "";

            if (sfd.ShowDialog() == true)
            {
                fileName = sfd.FileName;
                System.Windows.Size size = inkPresenter.RenderSize;
                RenderTargetBitmap rtb = new RenderTargetBitmap((int)size.Width, (int)size.Height, 96, 96, PixelFormats.Pbgra32);
                rtb.Render(inkPresenter);
                PngBitmapEncoder png = new PngBitmapEncoder();
                png.Frames.Add(BitmapFrame.Create(rtb));
                using (Stream stm = File.Create(fileName))
                {
                    png.Save(stm);
                }
            }
        }

        private void Open_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "bmp图片|*.bmp|jpg图片|*.jpg|gif图片|*.gif|png图片|*.png";
            string fileName = "";
            if (ofd.ShowDialog() == true)
            {
                fileName = ofd.FileName;
                CreateVisual(fileName);
            }
        }


        //private void color_Click(object sender, RoutedEventArgs e)
        //{
        //    System.Windows.Forms.ColorDialog colorDialog = new System.Windows.Forms.ColorDialog();
        //    colorDialog.AllowFullOpen = true;
        //    colorDialog.ShowDialog();
        //    System.Windows.Media.SolidColorBrush scb = new System.Windows.Media.SolidColorBrush();
        //    System.Windows.Media.Color color = new System.Windows.Media.Color();
        //    color.A = colorDialog.Color.A;
        //    color.B = colorDialog.Color.B;
        //    color.G = colorDialog.Color.G;
        //    color.R = colorDialog.Color.R;
        //    scb.Color = color;

        //    // run.Foreground = scb;
        //    if (inkDrawing != null)
        //        inkDrawing.DrawingAttributes.Color = scb.Color;
        //    //inkDrawing.DrawingAttributes.Color = GetRandomColor();
        //}

        private void save_Click(object sender, RoutedEventArgs e)
        {

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "bmp图片|*.bmp|jpg图片|*.jpg|gif图片|*.gif|png图片|*.png";
            string fileName = "";

            if (sfd.ShowDialog() == true)
            {
                fileName = sfd.FileName;
                System.Windows.Size size = inkPresenter.RenderSize;
                RenderTargetBitmap rtb = new RenderTargetBitmap((int)size.Width, (int)size.Height, 96, 96, PixelFormats.Pbgra32);
                rtb.Render(inkPresenter);
                PngBitmapEncoder png = new PngBitmapEncoder();
                png.Frames.Add(BitmapFrame.Create(rtb));
                using (Stream stm = File.Create(fileName))
                {
                    png.Save(stm);
                }
            }
        }

        private void inkEraseByRect(System.Windows.Point ePoint)    //ePoint=我所指到的Location
        {
            System.Windows.Controls.Image img = new System.Windows.Controls.Image();
            Rect rect = new Rect(ePoint.X, ePoint.Y,40, 40);    //設定Rect
            InkCanvas.SetLeft(img, rect.Left);    //設定橡皮插圖案Location
            InkCanvas.SetTop(img, rect.Top);
            this.inkPresenter.Strokes.Erase(rect);    //擦一個矩形居快的筆跡
        }

        private void inkPresenter_MouseMove(object sender, MouseEventArgs e)
        {
            if (flag == true)
            {
                System.Windows.Point p = new System.Windows.Point();
                System.Windows.Point pp = Mouse.GetPosition(e.Source as FrameworkElement);//WPF方法
                System.Windows.Point ppp = (e.Source as FrameworkElement).PointToScreen(pp);//WPF方法
                inkEraseByRect(pp);

            }
        }

        private void open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "bmp图片|*.bmp|jpg图片|*.jpg|gif图片|*.gif|png图片|*.png";
            string fileName = "";
            if (ofd.ShowDialog() == true)
            {
                fileName = ofd.FileName;
                CreateVisual(fileName);
            }
        }

        private Visual CreateVisual(string Imgfilename)
        {
            BitmapImage bmp = new BitmapImage(new Uri(Imgfilename));
            System.Windows.Controls.Image img = new System.Windows.Controls.Image();
            img.Source = bmp;
            inkPresenter.Child = img;
            return inkPresenter;
        }

        private void Brush1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Brush1.Opacity = 1;
            ClipClear.Opacity = 0;
            brush5.Opacity = 0;
            brush4.Opacity = 0;
            if (inkDrawing != null)
            {
                inkDrawing.Mode = InkDrawingMode.Draw;
                inkDrawing.DrawingAttributes.Width = inkDrawing.DrawingAttributes.Height =10;
            }
            flag = false;
        }

        private void revoke_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            revoke.Opacity =0;
            Brush1.Opacity = 0;
            ClipClear.Opacity = 0;
            brush5.Opacity = 0;
            brush4.Opacity = 0;
        }

        private void ClipClear_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ClipClear.Opacity = 1;
            Brush1.Opacity = 0;
            brush5.Opacity = 0;
            brush4.Opacity = 0;
            flag = true;
        }

        private void Ellipse_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //img = new System.Windows.Controls.Image();
            slider2.Value = 0;
            slider.Value = 10;
            Ellipse ellipse = (Ellipse)sender;

            //Thickness thick = new Thickness();
            //thick=ellipse.Margin;
            //img.Margin = thick;
            //img.Name = "img1";
            //img.Width =60;
            //img.Height = 60;
            //img.Source =  new BitmapImage(new Uri(@"F:\工作\源码\审核代码\10月份\10.13\3\MgenWPFPaint\images\选中框.png"));
            //img.Stretch=Stretch.Fill;
            //grid1.Children.Add(img);
            System.Windows.Media.Color color = ((SolidColorBrush)ellipse.Fill).Color;
            inkDrawing.DrawingAttributes.Color = color;
            
        }

        private void brush5_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            brush5.Opacity =1;
            ClipClear.Opacity = 0;
            Brush1.Opacity = 0;
            brush4.Opacity = 0;
            if (inkDrawing != null)
            {
                inkDrawing.Mode = InkDrawingMode.Draw;
                inkDrawing.DrawingAttributes.Width = inkDrawing.DrawingAttributes.Height =70;
                
            }
            
            flag = false;
        }

        private void brush4_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            brush4.Opacity = 1;
            brush5.Opacity =0;
            ClipClear.Opacity = 0;
            Brush1.Opacity = 0;
            if (inkDrawing != null)
            {
                inkDrawing.Mode = InkDrawingMode.Draw;
                inkDrawing.DrawingAttributes.Width = inkDrawing.DrawingAttributes.Height =40;
            }
            flag = false;
        }

        private void revoke_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            revoke.Opacity = 1;
            Brush1.Opacity = 0;
            ClipClear.Opacity = 0;
            brush5.Opacity = 0;
            brush4.Opacity = 0;
        }

        private void playmusic_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            playmusic.Opacity = 1;
            brush4.Opacity = 0;
            brush5.Opacity = 0;
            ClipClear.Opacity = 0;
            Brush1.Opacity = 0;

            if (num%2== 0)
            {
                player.Close();
                player.Stop();
            }
            else
            {
                player.Volume = 100;
                player.Open(new Uri(@"E:\项目\MgenWPFPaint\music\xiaopingguo.wav"));
                player.Play();
            }
            num++;
        }

        private void playmusic_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            playmusic.Opacity =0;
            brush4.Opacity = 0;
            brush5.Opacity = 0;
            ClipClear.Opacity = 0;
            Brush1.Opacity = 0;
        }

        private void print_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PrintDialog dialog = new PrintDialog();
            if (dialog.ShowDialog() == true)
            {
                dialog.PrintVisual(inkPresenter, "Print Test");
            }
        }


        private void slider2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (inkDrawing != null)
            {
                int value = Convert.ToInt32(slider2.Maximum- slider2.Value);

                string strvalue = Convert.ToString(value, 16);
                byte b = Convert.ToByte(strvalue,16);
                inkDrawing.DrawingAttributes.Color = System.Windows.Media.Color.FromArgb(b, inkDrawing.DrawingAttributes.Color.R, inkDrawing.DrawingAttributes.Color.G, inkDrawing.DrawingAttributes.Color.B);
            }
        }

    }
    }

