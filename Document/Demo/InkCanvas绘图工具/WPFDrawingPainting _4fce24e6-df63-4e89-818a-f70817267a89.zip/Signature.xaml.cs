﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace mgen_ink_wpf
{
    /// <summary>
    /// Signature.xaml 的交互逻辑
    /// </summary>
    public partial class Signature : Window
    {

        public Signature()
        {
            InitializeComponent();
        }

        private void Image_MouseEnter(object sender, MouseEventArgs e)
        {
           // 下载于www.51aspx.com
        }

        private void imgAgain_MouseEnter(object sender, MouseEventArgs e)
        {
            Uri uri = new Uri(@"F:\工作\源码\审核代码\10月份\10.13\3\MgenWPFPaint\images\再来-1.png");
            BitmapImage bimg = new BitmapImage(uri);
            imgAgain.Source = bimg;
        }

        private void imgAgain_MouseLeave(object sender, MouseEventArgs e)
        {
            Uri uri = new Uri(@"F:\工作\源码\审核代码\10月份\10.13\3\MgenWPFPaint\images\再来-2.png");
            BitmapImage bimg = new BitmapImage(uri);
            imgAgain.Source = bimg;
        }

        private void imgAgain_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ClearStrokes();
        }

        private void imgSave_MouseEnter(object sender, MouseEventArgs e)
        {
            Uri uri = new Uri(@"F:\工作\源码\审核代码\10月份\10.13\3\MgenWPFPaint\images\签名-1.png");
            BitmapImage bimg = new BitmapImage(uri);
            imgSave.Source = bimg;
        }

        private void imgSave_MouseLeave(object sender, MouseEventArgs e)
        {
            Uri uri = new Uri(@"F:\工作\源码\审核代码\10月份\10.13\3\MgenWPFPaint\images\签名-2.png");
            BitmapImage bimg = new BitmapImage(uri);
            imgSave.Source = bimg;
        }

        private void imgSave_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Rect rect = this.inkcanvas.Strokes.GetBounds();
            if (rect.Height <= 0 || rect.Width <= 0)
            {
                System.Windows.MessageBox.Show("请先签名！");
                return;
            }
            RenderTargetBitmap rtb = new RenderTargetBitmap((int)this.inkcanvas.ActualWidth, (int)this.inkcanvas.ActualHeight, 0, 0, PixelFormats.Pbgra32);
            //-marg
            rtb.Render(this.inkcanvas);

            PngBitmapEncoder nencoder = new PngBitmapEncoder();
            MemoryStream ms = new MemoryStream();

            nencoder.Frames.Add(BitmapFrame.Create(rtb));
            nencoder.Save(ms);
            Bitmap bp = new Bitmap(ms);
            // 下载于www.51aspx.com
            string saveDir = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase + @"SingFile/";
            if (!Directory.Exists(saveDir))
            {
                Directory.CreateDirectory(saveDir);
            }
            string fileName = DateTime.Now.ToString("yyyyMMddhhmmss") + DateTime.Now.Minute + DateTime.Now.Millisecond.ToString() + ".jpg";
            string filePath = System.IO.Path.Combine(saveDir, fileName);
            bp.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);
            bp.Dispose();
            ms.Close();
            this.inkcanvas.Strokes.Clear();
        }



        private void ClearStrokes()
        {
            this.inkcanvas.Strokes.Clear();
        }

        private void imgPrint_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            PrintDialog dialog = new PrintDialog();
            if (dialog.ShowDialog() == true)
            {
                dialog.PrintVisual(inkcanvas, "Print Test");
            }
        }

        private void imgPrint_MouseEnter(object sender, MouseEventArgs e)
        {
            Uri uri = new Uri(@"F:\工作\源码\审核代码\10月份\10.13\3\MgenWPFPaint\images\打印-1.png");
            BitmapImage bimg = new BitmapImage(uri);
            imgPrint.Source = bimg;
        }

        private void imgPrint_MouseLeave(object sender, MouseEventArgs e)
        {
            Uri uri = new Uri(@"F:\工作\源码\审核代码\10月份\10.13\3\MgenWPFPaint\images\打印-2.png");
            BitmapImage bimg = new BitmapImage(uri);
            imgPrint.Source = bimg;
        }


    }
}
