﻿namespace mgen_ink_wpf
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    //|5|1|a|s|p|x
    #region Enumerations

    enum InkDrawingMode
    {
        Draw, Erase
    }

    #endregion Enumerations

    class InkDrawing
    {
        #region Fields

        Stroke currStroke;
        InkPresenter inkPresneter;

        #endregion Fields

        #region Constructors

        public InkDrawing(InkPresenter ink, IInputElement eventRecv)
        {
            if (ink == null)
            {
                throw new ArgumentNullException("ink");
            }
            if (eventRecv == null)
            {
                throw new ArgumentNullException("eventRecv");
            }

            inkPresneter = ink;
            DrawingAttributes = new DrawingAttributes();
            DrawingAttributes.Color = Colors.Black;
            DrawingAttributes.Width = DrawingAttributes.Height = 5;
            IsMouseDrawingEnabled = true;
            IsMouseCaptureEnabled = true;

            eventRecv.PreviewMouseLeftButtonDown += inkPresneter_MouseLeftButtonDown;
            eventRecv.PreviewMouseLeftButtonUp += inkPresneter_MouseLeftButtonUp;
            eventRecv.PreviewMouseMove += inkPresneter_MouseMove;
        }

        #endregion Constructors

        #region Properties

        public DrawingAttributes DrawingAttributes
        {
            get; private set;
        }

        public bool IsMouseCaptureEnabled
        {
            get; set;
        }

        public bool IsMouseDrawingEnabled
        {
            get; set;
        }

        public InkDrawingMode Mode
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public void Clear()
        {
            inkPresneter.Strokes.Clear();
        }

        public void SetThickness(double thick)
        {
            DrawingAttributes.Width = DrawingAttributes.Height = thick;
        }

       public void Erase(Point pt)
        {
            var hitResult = inkPresneter.Strokes.HitTest(pt);
            foreach (var s in hitResult)
            {
                inkPresneter.Strokes.Remove(s);
            }
        }

        void inkPresneter_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!IsMouseDrawingEnabled)
                return;

            if (IsMouseCaptureEnabled)
                inkPresneter.CaptureMouse();

            var currPoint = e.GetPosition(inkPresneter);
            if (Mode == InkDrawingMode.Draw)
            {
                var collection = new StylusPointCollection();
                collection.Add(PointToStylusPoint(currPoint));
                currStroke = new Stroke(collection);
                currStroke.DrawingAttributes.Color = DrawingAttributes.Color;
                currStroke.DrawingAttributes.Height = DrawingAttributes.Height;
                currStroke.DrawingAttributes.Width = DrawingAttributes.Width;
                inkPresneter.Strokes.Add(currStroke);
            }
        }

        void inkPresneter_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!IsMouseDrawingEnabled)
                return;

            if (IsMouseCaptureEnabled)
                inkPresneter.ReleaseMouseCapture();

            currStroke = null;
        }

       void inkPresneter_MouseMove(object sender, MouseEventArgs e)
        {
            if (!IsMouseDrawingEnabled)
                return;

            if (Mode == InkDrawingMode.Draw)
            {
                if (currStroke == null)
                    return;

                currStroke.StylusPoints.Add(PointToStylusPoint(e.GetPosition(inkPresneter)));
            }
            else if (e.LeftButton == MouseButtonState.Pressed)
            {
                Erase(e.GetPosition(inkPresneter));
            }
        }

        StylusPoint PointToStylusPoint(Point p)
        {
            return new StylusPoint(p.X, p.Y);
        }

        #endregion Methods
    }
}