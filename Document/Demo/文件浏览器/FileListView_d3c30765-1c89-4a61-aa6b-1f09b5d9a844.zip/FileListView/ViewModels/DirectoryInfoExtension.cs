namespace FileListView.ViewModels
{
  using System.IO;
  using System.Linq;
  using System.Collections.Generic;

  /// <summary>
  /// Class implements an extension of the <seealso="DirectoryInfo"> class.
  /// </summary>
  public static class DirectoryInfoExtension
  {
    /// <summary>
    /// Method implements an extension that lets us filter files
    /// with multiple filter aruments.
    /// </summary>
    /// <param name="dir">Points at the folder that is queried for files and folder entries.</param>
    /// <param name="extensions">Contains the extension that we want to file for, eg: string[]{"*.*"} or string[]{"*.tex", "*.txt"}</param>
    public static IEnumerable<FileInfo> GetFilesByExtensions(this DirectoryInfo dir,
                                                             params string[] extensions)
    {
       if (extensions == null) 
         throw new System.ArgumentNullException("extensions");
    
       IEnumerable<FileInfo> files = Enumerable.Empty<FileInfo>();
       foreach(string ext in extensions)
       {
         files = files.Concat(dir.GetFiles(ext));
       }
    
       return files;
    }
  }
}
