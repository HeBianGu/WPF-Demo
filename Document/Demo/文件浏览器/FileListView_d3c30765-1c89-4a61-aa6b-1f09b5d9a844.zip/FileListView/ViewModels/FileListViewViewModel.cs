namespace FileListView.ViewModels
{
  using System;
  using System.Collections.Generic;
  using System.Collections.ObjectModel;
  using System.IO;
  using System.Linq;
  using System.Text;
  using System.Threading.Tasks;
  using System.Windows.Input;
  using System.Windows.Media;
  using System.Windows.Media.Imaging;
  using FileListView.Command;
  using FileListView.Events;

  /// <summary>
  /// Class implements ...
  /// </summary>
  public class FileListViewViewModel : Base.ViewModelBase
  {
    #region fields
    /// <summary>
    /// Determines whether the redo stack (FutureFolders) should be cleared when the CurrentFolder changes next time
    /// </summary>
    private string mFilterString = string.Empty;

    private bool mShowFolders = true;
    private bool mShowHidden = true;
    private bool mShowIcons = true;

    private RelayCommand<object> mDoubleClickCommand = null;        

    private RelayCommand<object> mUpCommand = null;
    private RelayCommand<object> mForwardCommand = null;
    private RelayCommand<object> mBackCommand = null;
    #endregion fields

    #region constructor
    /// <summary>
    /// Class constructor
    /// </summary>
    public FileListViewViewModel()
    {
      this.CurrentItems = new ObservableCollection<FSItemVM>();
      this.RecentFolders = new Stack<string>();
      this.FutureFolders = new Stack<string>();
    }
    #endregion constructor

    #region Events
    /// <summary>
    /// Event is fired to indicate that user wishes to open a file via this viewmodel.
    /// </summary>
    public event EventHandler<FileOpenEventArgs> OnFileOpen;

    /// <summary>
    /// Event is fired whenever the path in the text portion of the combobox is changed.
    /// </summary>
    public event EventHandler<FolderChangedEventArgs> OnCurrentPathChanged;
    #endregion

    #region properties
    /// <summary>
    /// Gets/sets list of files and folders to be displayed in connected view.
    /// </summary>
    public ObservableCollection<FSItemVM> CurrentItems { get; set; }

    /// <summary>
    /// Gets/sets whether the list of folders and files should include folders or not.
    /// </summary>
    public bool ShowFolders
    {
      get
      {
        return this.mShowFolders;
      }

      set
      {
        if (this.mShowFolders != value)
        {
          this.mShowFolders = value;
          this.NotifyPropertyChanged(() => this.ShowFolders);
        }
      }
    }

    /// <summary>
    /// Gets/sets whether the list of folders and files includes hidden folders or files.
    /// </summary>
    public bool ShowHidden
    {
      get
      {
        return this.mShowHidden;
      }

      set
      {
        if (this.mShowHidden != value)
        {
          this.mShowHidden = value;
          this.NotifyPropertyChanged(() => this.ShowHidden);
        }
      }
    }

    public bool ShowIcons
    {
      get
      {
        return this.mShowIcons;
      }

      set
      {
        if (this.mShowIcons != value)
        {
          this.mShowIcons = value;
          this.NotifyPropertyChanged(() => this.ShowIcons);
        }
      }
    }

    #region commands
    public ICommand DoubleClickCommand
    {
      get
      {
        if (this.mDoubleClickCommand == null)
          this.mDoubleClickCommand = new RelayCommand<object>((p) => this.DoubleClickCommand_Executed(p));

        return this.mDoubleClickCommand;
      }
    }

    public ICommand UpCommand
    {
      get
      {
        if (this.mUpCommand == null)
          this.mUpCommand = new RelayCommand<object>((p) => this.Up());

        return this.mUpCommand;
      }
    }

    public ICommand ForwardCommand
    {
      get
      {
        if (this.mForwardCommand == null)
          this.mForwardCommand = new RelayCommand<object>((p) => this.Forward(),
                                                          (p) => this.FutureFolders.Count > 0);

        return this.mForwardCommand;
      }
    }
    
    public ICommand BackCommand
    {
      get
      {
        if (this.mBackCommand == null)
          this.mBackCommand = new RelayCommand<object>((p) => this.Back(),
                                                       (p) => this.RecentFolders.Count > 0);


        return this.mBackCommand;
      }
    }        
    #endregion commands

    /// <summary>
    /// Gets/sets the current folder which is being
    /// queried to list the current files and folders for display.
    /// </summary>
    private string CurrentFolder { get; set; }

    /// <summary>
    /// Gets/sets the undo stacks for navigation.
    /// </summary>
    private Stack<string> RecentFolders { get; set; }

    /// <summary>
    /// Gets/sets the redo stack for navigation.
    /// </summary>
    private Stack<string> FutureFolders { get; set; }
    #endregion properties

    #region methods
    /// <summary>
    /// Fills the CurrentItems property for display in ItemsControl
    /// based view (ListBox, ListView etc.)
    /// </summary>
    public void PopulateView()
    {
      this.CurrentItems.Clear();

      if (this.IsPathDirectory(this.CurrentFolder) == false)
        return;

      try
      {
        DirectoryInfo cur = new DirectoryInfo(this.CurrentFolder);
        ImageSource dummy = new BitmapImage();

        if (this.ShowFolders)
        {
          foreach (DirectoryInfo dir in cur.GetDirectories())
          {
            if (dir.Attributes.HasFlag(FileAttributes.Hidden) == true)
            {
              if (this.ShowHidden == false)
              {
                if ((dir.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
                  continue;
              }
            }

            FSItemVM info = new FSItemVM()
            {
              FullPath = dir.FullName,
              DisplayName = dir.Name,
              Type = FSItemType.Folder
            };

            if (this.ShowIcons == false)
              info.DisplayIcon = dummy;  // to prevent the icon from being loaded from file later

            this.CurrentItems.Add(info);
          }
        }

        string[] filterString = {"*.*"};

        if (string.IsNullOrEmpty(this.mFilterString) == false)
        {
          if (this.mFilterString.Split('|').Length > 1)
            filterString = this.mFilterString.Split('|');
          else
            filterString = new string[] { this.mFilterString };
        }
       
        ////if (this.mFileListView.FilterIndex >= 0 && this.mFileListView.FilterIndex < this.FilterCount)
        ////  filterString = this.FilterList[this.mFileListView.FilterIndex].ToString();

        foreach (FileInfo f in cur.GetFilesByExtensions(filterString))
        {
            if (this.ShowHidden == false)
            {
              if (f.Attributes.HasFlag(FileAttributes.Hidden) == true)
              {
                if ((f.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
                  continue;
              }
            }

          FSItemVM info = new FSItemVM()
          {
            FullPath = f.FullName,
            DisplayName = f.Name,   // System.IO.Path.GetFileName(s),
            Type = FSItemType.File
          };

          if (this.ShowIcons == false)
            info.DisplayIcon = dummy;  // to prevent the icon from being loaded from file later

          this.CurrentItems.Add(info);
        }
      }
      catch
      {
      }

      // reset column width manually (otherwise it is not updated)
      ////this.mFileListView.TheGVColumn.Width = this.mFileListView.TheGVColumn.ActualWidth;
      ////this.mFileListView.TheGVColumn.Width = double.NaN;
    }

    /// <summary>
    /// Navigates to a previously visited folder (if any).
    /// </summary>
    public void Back()
    {
      if (this.RecentFolders.Count > 0)
      {
        // top of stack is always last valid folder
        this.FutureFolders.Push(this.CurrentFolder);
        this.CurrentFolder = this.RecentFolders.Pop();

        if (this.OnCurrentPathChanged != null)
          this.OnCurrentPathChanged(this, new FolderChangedEventArgs() { FilePath = this.CurrentFolder });
      }
    }

    /// <summary>
    /// Navigates to a folder that was visited before navigating back (if any).
    /// </summary>
    public void Forward()
    {
      if (this.FutureFolders.Count > 0)
      {
        this.RecentFolders.Push(this.CurrentFolder);
        this.CurrentFolder = this.FutureFolders.Pop();

        if (this.OnCurrentPathChanged != null)
          this.OnCurrentPathChanged(this, new FolderChangedEventArgs() { FilePath = this.CurrentFolder });
      }
    }

    public void Up()
    {
      string[] dirs = this.CurrentFolder.Split(new char[] { System.IO.Path.DirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
      if (dirs.Length > 1)
      {
        string newf = string.Join(System.IO.Path.DirectorySeparatorChar.ToString(), dirs, 0, dirs.Length - 1);

        if (dirs.Length == 2)
          newf += System.IO.Path.DirectorySeparatorChar;

        this.RecentFolders.Push(this.CurrentFolder);
        this.FutureFolders.Clear();
        this.CurrentFolder = newf;

        if (this.OnCurrentPathChanged != null)
          this.OnCurrentPathChanged(this, new FolderChangedEventArgs() { FilePath = this.CurrentFolder });
      }
    }

    internal void ApplyFilter(string filterText)
    {
      this.mFilterString = filterText;
      this.PopulateView();
    }

    internal void UpdateView(string p)
    {
      if (string.IsNullOrEmpty(p) == true)
        return;

      this.CurrentFolder = p;
      this.PopulateView();      
    }

    /// <summary>
    /// Methid is executed when a listview item is double clicked.
    /// </summary>
    /// <param name="p"></param>
    private void DoubleClickCommand_Executed(object p)
    {
      FSItemVM info = p as FSItemVM;

      if (info != null)
      {
        if (info.Type == FSItemType.Folder)
        {
          this.RecentFolders.Push(this.CurrentFolder);
          this.FutureFolders.Clear();
          this.CurrentFolder = info.FullPath;
          this.PopulateView();

          if (this.OnCurrentPathChanged != null)
            this.OnCurrentPathChanged(this, new FolderChangedEventArgs() { FilePath = info.FullPath });
        }
        else
        {
          if (info.Type == FSItemType.File && this.OnFileOpen != null)
            this.OnFileOpen(this, new FileOpenEventArgs() { FileName = info.FullPath });
        }
      }
    }

    /// <summary>
    /// Determine whether a given path is an exeisting directory or not.
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    private bool IsPathDirectory(string path)
    {
      if (string.IsNullOrEmpty(path) == true)
        return false;

      bool IsPath = false;

      try
      {
        IsPath = System.IO.Directory.Exists(path);
      }
      catch
      {
      }

      return IsPath;
    }
    #endregion methods
  }
}
