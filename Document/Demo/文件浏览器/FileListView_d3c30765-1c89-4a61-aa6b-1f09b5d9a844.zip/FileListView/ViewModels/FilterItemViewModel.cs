namespace FileListView.ViewModels
{
  using System;
  using System.Windows.Media;

  /// <summary>
  /// The Viewmodel for filter item displayed in list of filters
  /// </summary>
  public class FilterItemViewModel : Base.ViewModelBase
  {
    #region fields
    private string mFilterText = string.Empty;
    #endregion fields

    #region constructor
    /// <summary>
    /// Class constructor
    /// </summary>
    public FilterItemViewModel(string filter = "")
    {
      if (string.IsNullOrEmpty(filter) == false)
      {
        this.mFilterText = filter;
      }
    }
    #endregion constructor
    
    #region properties
    public string FilterText
    {
      get
      {
        return this.mFilterText;
      }

      set
      {
        if (this.mFilterText != value)
        {
          this.mFilterText = value;
          this.NotifyPropertyChanged(() => this.FilterText);
        }
      }
    }
    #endregion properties

    #region methods
    /// <summary>
    /// Standard method to display contents of this class.
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
      return this.FilterText;
    }
    #endregion methods
  }
}
