﻿namespace FolderBrowser
{
  using System.Windows.Controls;

  /// <summary>
  /// Interaction logic for BrowseDirectoriesView.xaml
  /// </summary>
  public partial class BrowseDirectoriesView : UserControl
  {
    public BrowseDirectoriesView()
    {
      this.InitializeComponent();
    }
  }
}
