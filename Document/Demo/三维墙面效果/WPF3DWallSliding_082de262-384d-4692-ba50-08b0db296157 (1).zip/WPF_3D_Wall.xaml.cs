﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Media.Media3D;
using System.Windows.Media.Animation;
using System.Xml;
using Micr3_3D;
// 下载于www.51aspx.com
namespace WpfApplication1
{
    /// <summary>
    /// WPF_3D_Wall.xaml 的交互逻辑
    /// </summary>
    public partial class WPF_3D_Wall : Window
    {
        private PerspectiveCamera camera = null;
        private Viewport3D viewport3D = null;
        private ModelVisual3D modelVisual3D = null;
        private TranslateTransform3D translate = null;

        //3D图片左右间距
        private double picLeftToRightDis = 2.8;
        //3D图片上下间距
        private double picTopToButtomDis = -2.2;
        //3D图片第一张图片X轴坐标
        private double picStartPositionX = -SystemParameters.PrimaryScreenWidth * 0.0038;
        //3D图片第一张图片Y轴坐标
        private double picStartPositionY = SystemParameters.PrimaryScreenHeight * 0.003;
        //3D图片Z轴坐标,不会改变
        private const double picStartPositionZ = -8;

        private double oldMouseX = 0.0;
        private double tempCameraPositionX = 0.0;
        private double tempLookDirectionX = 0.0;

        public WPF_3D_Wall()
        {
            InitializeComponent();
            show3DWall();
            CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
        }

        void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            if(camera != null){
                tempCameraPositionX *= 0.8;
                camera.Position = new Point3D(camera.Position.X + tempCameraPositionX, 0, 8);
                tempLookDirectionX *= 0.99;
                camera.LookDirection = new Vector3D(tempLookDirectionX, 0, -1);
            }
        }

        private void show3DWall() {
            Micr3_3D_Controller controller = new Micr3_3D_Controller();
            viewport3D = controller.getViewport3D();
            Point3D cameraPosition = new Point3D(0, 0, 8);
            Vector3D cameraLookDirection = new Vector3D(0, 0, -1);
            Vector3D cameraUpDirection = new Vector3D(0, 1, 0);
            camera = controller.getCamera(cameraPosition, cameraLookDirection, cameraUpDirection, 100, 0.125, 45);
            viewport3D.Camera = camera;

            Random random = new Random();
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load("Image/Photos.xml");
            XmlNode root = xmlDocument.DocumentElement;
            modelVisual3D = controller.getModel3D(picStartPositionX, picStartPositionY, picStartPositionZ, root.ChildNodes[0].InnerText.ToString());
            viewport3D.Children.Add(modelVisual3D);
            for (int i = 1; i < root.ChildNodes.Count; i++)
            {
                if (i % 3 == 0)
                {
                    translate = (TranslateTransform3D)viewport3D.Children[viewport3D.Children.Count - 3].Transform;
                    modelVisual3D = controller.getModel3D(translate.OffsetX + picLeftToRightDis, translate.OffsetY, picStartPositionZ, root.ChildNodes[i].InnerText.ToString());
                }
                else
                {
                    translate = (TranslateTransform3D)viewport3D.Children[viewport3D.Children.Count - 1].Transform;
                    modelVisual3D = controller.getModel3D(translate.OffsetX, translate.OffsetY + picTopToButtomDis, picStartPositionZ, root.ChildNodes[i].InnerText.ToString());
                }
                viewport3D.Children.Add(modelVisual3D);
            }
            viewport3D.Children.Add(controller.getLight());
            //Border border = new Border();
            //border.BorderThickness = new Thickness(12);
            //border.BorderBrush = Brushes.Transparent;
            //border.Child = viewport3D;
            grid.Children.Add(viewport3D);
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed) {
                tempCameraPositionX += (oldMouseX - e.GetPosition(this).X) * 0.01;
                if (tempCameraPositionX >= 0)
                    tempLookDirectionX += 0.02;
                else
                    tempLookDirectionX -= 0.02;
            }
            oldMouseX = e.GetPosition(this).X;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
           
        }

        private void Window_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
