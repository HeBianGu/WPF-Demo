﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Media3D;
using System.Xml;
using System.Windows.Media.Animation;
using System.Diagnostics;
using Micr3_3D;

namespace WpfApplication1
{
    /// <summary>
    /// Window1.xaml 的互動邏輯
    /// </summary>
    public partial class Window1 : Window
    {
        private PerspectiveCamera camera = null;
        private Viewport3D viewport3D = null;
        private int fix = 2;
        private double flag = -3;
        private int index = 1;
        private double oldSlider = 0;
        private int imageNumber = 0;

        private double cameraX = 0.0;
        private double cameraY = 1.0;
        private double cameraZ = 0.0;

        //滚轮方向
        private bool deltaBool = false;
        private double oldMouseY = 0.0; 

        public Window1()
        {
            InitializeComponent();
            showModel();
            CompositionTarget.Rendering += new EventHandler(CompositionTarget_Rendering);
        }

        void CompositionTarget_Rendering(object sender, EventArgs e)
        {
            if(camera != null){
                if (viewport3D != null)
                {
                    ModelVisual3D model3D = (ModelVisual3D)viewport3D.Children[index];
                    TranslateTransform3D transform = (TranslateTransform3D)model3D.Transform;
                    GeometryModel3D gemotry3D = (GeometryModel3D)model3D.Content;
                    DiffuseMaterial diffuseMaterial = (DiffuseMaterial)gemotry3D.Material;
                    ImageBrush imageBrush = (ImageBrush)diffuseMaterial.Brush;
                    if (deltaBool)
                    {
                        if (imageBrush.Opacity < 0.01)
                        {
                            imageBrush.Opacity = 0;
                            if (index > 0)
                                index--;
                        }
                        if (camera.Position.Z - transform.OffsetZ <= 10 && camera.Position.Z - transform.OffsetZ >= 7)
                        {
                            if (imageBrush.Opacity != 0)
                                imageBrush.Opacity *= 0.9;
                        }
                        else if (camera.Position.Z - transform.OffsetZ < 7)
                        {
                            imageBrush.Opacity = 0;
                        }
                    }
                    else
                    {
                        if (imageBrush.Opacity >= 0.96)
                        {
                            imageBrush.Opacity = 1;
                            if (index < imageNumber - 1)
                                index++;
                        }
                        if (camera.Position.Z - transform.OffsetZ <= 8 && camera.Position.Z - transform.OffsetZ >= 5)
                        {
                            if (imageBrush.Opacity < 1)
                                imageBrush.Opacity += 0.05;
                        }
                        else if (camera.Position.Z - transform.OffsetZ > 8)
                        {
                            imageBrush.Opacity = 1;
                        }
                    }
                }
                cameraZ *= 0.96;
                camera.Position = new System.Windows.Media.Media3D.Point3D(cameraX, cameraY,camera.Position.Z + cameraZ);
            }
        }

        public void showModel(){
            Micr3_3D_Controller controller = new Micr3_3D_Controller();
            viewport3D = controller.getViewport3D();
            Point3D cameraPosition = new Point3D(0, 0, 0);
            Vector3D cameraLookDirection = new Vector3D(0, 0, -1);
            Vector3D cameraUpDirection = new Vector3D(0, 1, 0);
            camera = controller.getCamera(cameraPosition, cameraLookDirection, cameraUpDirection,100,0.125,45);
            viewport3D.Camera = camera;

            Random random = new Random();
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load("Image/Photos.xml");
            XmlNode root = xmlDocument.DocumentElement;
            fix = root.ChildNodes.Count +2;
            index = root.ChildNodes.Count - 1;
            imageNumber = root.ChildNodes.Count;
            for (int i = root.ChildNodes.Count - 1; i >= 0;i--)
            {
                ModelVisual3D modelVisual3D = controller.getModel3D(-flag * random.NextDouble(), 0, -8 * fix--,root.ChildNodes[i].InnerText.ToString());
                viewport3D.Children.Add(modelVisual3D);
                flag = -flag;
            }
            viewport3D.Children.Add(controller.getLight());
            grid.Children.Add(viewport3D);
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider slider = (Slider)sender;
            if(camera != null){
               camera.Position = new System.Windows.Media.Media3D.Point3D(0, 0, -slider.Value);
               if (viewport3D != null) {
                   ModelVisual3D model3D = (ModelVisual3D)viewport3D.Children[index];
                   TranslateTransform3D transform = (TranslateTransform3D)model3D.Transform;
                   textBox1.Text = camera.Position.Z.ToString();
                   textBox2.Text = transform.OffsetZ.ToString();
                   textBox3.Text = index.ToString();
                   textBox5.Text = slider.Value.ToString();
                   GeometryModel3D gemotry3D = (GeometryModel3D)model3D.Content;
                   DiffuseMaterial diffuseMaterial = (DiffuseMaterial)gemotry3D.Material;
                   ImageBrush imageBrush = (ImageBrush)diffuseMaterial.Brush;
                    if (slider.Value - oldSlider > 0)
                    {
                        if (imageBrush.Opacity == 0)
                        {
                            imageBrush.Opacity = 0;
                            if(index > 0)
                                index--;
                        }
                        else
                        {
                            imageBrush.Opacity = Math.Abs(transform.OffsetZ - camera.Position.Z + 8) * 0.5;
                        }
                    }
                    else
                    {
                        if (camera.Position.Z - transform.OffsetZ >=8)
                        {
                            if (imageBrush.Opacity >= 0.9)
                            {
                                imageBrush.Opacity = 1;
                                if (index < imageNumber-1)
                                    index++;
                            }
                            else
                            {
                                if (Math.Abs(transform.OffsetZ - camera.Position.Z + 8) * 0.5 >= 1)
                                    imageBrush.Opacity = 0;
                                else
                                    imageBrush.Opacity = Math.Abs(transform.OffsetZ - camera.Position.Z + 8) * 0.5;
                            }
                        }
                           
                    }
                    textBox4.Text = imageBrush.Opacity.ToString();
               }
            }
            oldSlider = slider.Value;
        }

        private void Window_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0){
                cameraZ -= 0.5;
                deltaBool = true;
            }else{
                cameraZ += 0.5;
                deltaBool = false;
            }
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            cameraY =2.8*(SystemParameters.PrimaryScreenHeight * 0.001/2 - e.GetPosition(this).Y * 0.001);
            camera.LookDirection = new Vector3D(e.GetPosition(this).X * 0.0000000008, e.GetPosition(this).Y * 0.000000002, -0.0000115);
        }
    }
}
