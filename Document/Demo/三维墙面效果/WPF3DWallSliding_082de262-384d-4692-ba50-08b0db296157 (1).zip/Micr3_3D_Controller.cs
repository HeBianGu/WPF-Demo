﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Media.Media3D;
using System.Windows.Media;
using System.Windows;

namespace Micr3_3D
{
    class Micr3_3D_Controller
    {

        public Micr3_3D_Controller() { 
        
        }
        //Viewport3D
        public Viewport3D getViewport3D() {
            return new Viewport3D();
        }

        //摄像机
        public PerspectiveCamera getCamera(Point3D cameraPosition, Vector3D cameraLookDirection, Vector3D cameraUpDirection, double farPlaneDis, double nearPlaneDistance, double fieldOfView)
        {
            PerspectiveCamera pCamera = new PerspectiveCamera();
            pCamera.Position = cameraPosition;
            pCamera.LookDirection = cameraLookDirection;
            pCamera.UpDirection = cameraUpDirection;
            pCamera.FieldOfView = fieldOfView;
            pCamera.NearPlaneDistance = nearPlaneDistance;
            pCamera.FarPlaneDistance = farPlaneDis;
            return pCamera;
        }

        //光源
        public ModelVisual3D getLight()
        { 
            AmbientLight amLight = new AmbientLight();
            amLight.Color =Colors.White;
            ModelVisual3D modelVisualLight = new ModelVisual3D();
            modelVisualLight.Content = amLight;
            return modelVisualLight;
        }
        //模型
        public ModelVisual3D getModel3D(double offsetX, double offsetY, double offsetZ, string imagePath)
        {
            ModelVisual3D modelVisual3D = new ModelVisual3D();
            TranslateTransform3D tt3D = new TranslateTransform3D();
            tt3D.OffsetX = offsetX;
            tt3D.OffsetY = offsetY;
            tt3D.OffsetZ = offsetZ;
            modelVisual3D.Transform = tt3D;
            //一个带有材质或者画刷的形状
            GeometryModel3D geometryModel3D = new GeometryModel3D();
            //3D模型的形状 此形状Position以写死
            MeshGeometry3D meshGeometry3D = new MeshGeometry3D();
            //3D空间点集合
            Point3DCollection point3D_C = new Point3DCollection();
            Point3D point3D_1 = new Point3D(-1.2,0.9,0);
            Point3D point3D_2 = new Point3D(1.2,0.9,0);
            Point3D point3D_3 = new Point3D(-1.2,-0.9,0);
            Point3D point3D_4 = new Point3D(1.2,-0.9,0);
            point3D_C.Add(point3D_1);
            point3D_C.Add(point3D_2);
            point3D_C.Add(point3D_3);
            point3D_C.Add(point3D_4);
            meshGeometry3D.Positions = point3D_C;
            //法向量集合
            Vector3DCollection vectory3D_C = new Vector3DCollection();
            Vector3D vectory3D_1 = new Vector3D(0,0,1);
            Vector3D vectory3D_2 = new Vector3D(0,0,1);    
            Vector3D vectory3D_3 = new Vector3D(0,0,1);
            Vector3D vectory3D_4 = new Vector3D(0,0,1);
            vectory3D_C.Add(vectory3D_1);
            vectory3D_C.Add(vectory3D_2);
            vectory3D_C.Add(vectory3D_3);
            vectory3D_C.Add(vectory3D_4);
            meshGeometry3D.Normals = vectory3D_C;
            //纹理坐标集合
            PointCollection point_C = new PointCollection();
            Point point_1 = new Point(0,0);
            Point point_2 = new Point(1,0);
            Point point_3 = new Point(0,1);
            Point point_4 = new Point(1,1);
            point_C.Add(point_1);
            point_C.Add(point_2);
            point_C.Add(point_3);
            point_C.Add(point_4);
            meshGeometry3D.TextureCoordinates = point_C;
            //三角形索引集合
            Int32Collection int32_C = new Int32Collection();
            int32_C.Add(0);int32_C.Add(2);int32_C.Add(3);int32_C.Add(0);int32_C.Add(3);int32_C.Add(1);
            meshGeometry3D.TriangleIndices = int32_C;
            geometryModel3D.Geometry = meshGeometry3D;
            //材质
            DiffuseMaterial diffuseMaterial = new DiffuseMaterial();
            ImageSourceConverter convert = new ImageSourceConverter();
            ImageBrush imageBrush = new ImageBrush();
            imageBrush.ImageSource = (ImageSource)convert.ConvertFromString(imagePath);
            diffuseMaterial.Brush = imageBrush;
            geometryModel3D.Material = diffuseMaterial;
            modelVisual3D.Content = geometryModel3D;
            return modelVisual3D;
        }

    }
}
