﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DevComponents.WpfRibbon;
using WpfCap;
using VideoPlayer.Class;

namespace VideoPlayer
{
    /// <summary>
    /// Camera.xaml 的交互逻辑
    /// </summary>
    public partial class Camera : Window
    {
        private Player playerWin;
        public Camera()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 有参数的结构方法
        /// </summary>
        /// <param name="win">Player主窗体</param>
        /// <param name="e"></param>
        public Camera(Player win)
        {
            this.playerWin=win;
            InitializeComponent();
        }
        
        /// <summary>
        /// 初始化加载摄像设备选择
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Initialized(object sender, EventArgs e)
        {
            for (int i = 0; i < CapDevice.DeviceMonikes.Count(); i++)
            {
                this.cbCamera.Items.Add(CapDevice.DeviceMonikes[i].Name.Trim() + "-" + (i + 1).ToString());
            }
            if (this.cbCamera.Items.Count > 0)
            {
                this.cbCamera.SelectedItem = this.cbCamera.Items[0];
            }
        }

        /// <summary>
        /// 确定选择设备
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOK_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.playerWin.NewCamera(cbCamera.SelectedIndex);
            this.Close();
        }

        /// <summary>
        /// 关闭窗体
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.playerWin.CancelCamera();
            this.Close();
        }
    }
}
