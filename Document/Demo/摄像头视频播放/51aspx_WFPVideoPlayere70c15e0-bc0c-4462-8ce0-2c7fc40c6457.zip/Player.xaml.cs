﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Timers;
using System.Windows.Threading;
using AxShockwaveFlashObjects;
using DevComponents;
using WpfCap;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using VideoPlayer.Class;
using DevComponents.WpfRibbon;
using System.Xml;
using System.Xml.XPath;

namespace VideoPlayer
{
    ///<summary>
    ///播放器的播放状态
    ///</summary>
    public enum MediaStatus
    {
        /// <summary>
        ///播放
        /// </summary>
        Play,
        /// <summary>
        ///暂停
        /// </summary>
        Pause
    }
    /// <summary>
    /// 播放器的声音状态
    /// </summary>
    public enum SoundStatus
    {
        /// <summary>
        /// 声音
        /// </summary>
        Sound,
        /// <summary>
        /// 静音
        /// </summary>
        Mute
    }
    /// <summary>
    /// 播放器的计时器状态
    /// </summary>
    public enum TimeStatus
    {
        /// <summary>
        /// 系统时间
        /// </summary>
        SystemTime,
        /// <summary>
        /// 文件时间
        /// </summary>
        FileTime
    }
    /// <summary>
    /// 视频\摄像屏幕显示与隐藏
    /// </summary>
    public enum PlayCamera
    {
        /// <summary>
        /// 视频屏幕
        /// </summary>
        inkMediaPlay,
        /// <summary>
        /// 摄像屏幕
        /// </summary>
        inkCameraPlay
    }

    /// <summary>
    /// Player.xaml 的交互逻辑
    /// </summary>
    public partial class Player : AdvWindow
    {
        #region   变量声明
        /// <summary>
        /// 列表-名称
        /// </summary>
        private string ListNodeName = "";
        /// <summary>
        /// 列表-路径
        /// </summary>
        private string ListNodePath = "";
        /// <summary>
        /// 列表-长度
        /// </summary>
        private string ListNodeLength = "";
        /// <summary>
        /// 列表-播放时刻
        /// </summary>
        private string ListNodeTime = "";
        /// <summary>
        /// 播放器实体类
        /// </summary>
        public MediaPlayer MPPlayer = new MediaPlayer();
        /// <summary>
        /// 播放器状态
        /// </summary>
        private MediaStatus MSStatus = MediaStatus.Pause;
        /// <summary>
        /// 皮肤颜色选择
        /// </summary>
        private string ColorsTag;
        /// <summary>
        /// 播放模式选择
        /// </summary>
        private string ModePlayTag;
        /// <summary>
        /// 底部图片选择
        /// </summary>
        private string ImagesTag;
        /// <summary>
        /// 底部图片选择
        /// </summary>
        private string ImagesChanges;
        /// <summary>
        /// 选择播放文件（上一部，下一部）
        /// </summary>
        private string changes = "";
        /// <summary>
        /// 播放文件序号（上一部，下一部）
        /// </summary>
        private int number = 0;
        ///<summary>
        ///视频\摄像屏幕
        /// </summary>
        private PlayCamera PCink = PlayCamera.inkMediaPlay;
        ///<summary>
        ///播放器声音状态
        /// </summary>
        private SoundStatus SSStatus = SoundStatus.Sound;
        ///<summary>
        ///播放器计时器状态
        /// </summary>
        private TimeStatus TSStatus = TimeStatus.SystemTime;
        /// <summary>
        /// 播放器声音数值
        /// </summary>
        double sound = 0;
        /// <summary>
        /// 播放视频的总长时间
        /// </summary>
        private string MediaCountTime = string.Empty;
        /// <summary>
        /// 播放时间的响应的委托
        /// </summary>
        private delegate void DeleSetPosition();
        /// <summary>
        /// 用于定时计算，添加播放时间
        /// </summary>
        private System.Timers.Timer Timing = new System.Timers.Timer();
        /// <summary>
        /// 当前播放文件名
        /// </summary>
        private string FileName;
        /// <summary>
        /// 播放文件的总长时间
        /// </summary>
        private int MaxLen = 0;
        /// <summary>
        /// 播放flash文件
        /// </summary>
        public AxShockwaveFlash FlashShock;
        /// <summary>
        /// 加载flash文件【AxShockwaveFlash】的类
        /// </summary>
        public WindowsFormsHost FlashFormHost;
        /// <summary>
        /// 初始化视频文件名【首次打开程序时使用】
        /// </summary>
        private object InitPlayerPath = System.Windows.Application.Current.Resources["InitArgs"] ?? null;
        /// <summary>
        /// 标识当前的时间滑动条是否可以操作
        /// </summary>
        private bool IsChangeValue = false;
        /// <summary>
        /// 摄像头调用类
        /// </summary>
        public CapPlayer CameraPlayer;
        /// <summary>
        /// 系统时间显示
        /// </summary>
        private DispatcherTimer DTimer;
        /// <summary>
        /// 标识是否记忆播放
        /// </summary>
        private bool memoryPlay = true;
        #endregion

        
        public Player()
        {
            InitializeComponent();

            //定义系统时间计时器
            DTimer = new DispatcherTimer(DispatcherPriority.Normal);
            DTimer.Interval = TimeSpan.FromMilliseconds(1000);
            DTimer.Tick += new EventHandler(timer_Tick);

            DTimer.Start();
        }

        ///<summary>
        ///定义系统时间显示事件
        /// </summary>
        private void timer_Tick(object sender, EventArgs e)
        {
            this.tbTime.Text = DateTime.Now.Hour.ToString("D2") + " : " + DateTime.Now.Minute.ToString("D2") + " : " + DateTime.Now.Second.ToString("D2");
        }

        /// <summary>
        /// 关闭播放器事件
        /// 【要关闭窗体，计时器，播放器工具，清除相关摄像设备】
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Player_Closed(object sender, EventArgs e)
        {
            SaveVolumn();
            SavePlayTime();
            this.Close();
            this.MPPlayer.Close();
            this.MSStatus = MediaStatus.Pause;
            this.FileName = string.Empty;
            this.InkCanvas_Player.Children.Clear();
            this.InkCanvas_Camera.Children.Clear();
            if (this.CameraPlayer != null)
            {
                this.CameraPlayer.Dispose();
                this.CameraPlayer = null;
            }
        }

        /// <summary>
        /// 加载窗体事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Player_Loaded(object sender, RoutedEventArgs e)
        {
            this.MPPlayer.MediaOpened += new EventHandler(MPPlayer_MediaOpened);
            this.MPPlayer.MediaEnded +=new EventHandler(MPPlayer_MediaEnded);
            this.Timing.Elapsed += new ElapsedEventHandler(Tim_Elapsed);

            ChangeColors();
            ChangeShowPlay();
            ChangeShowMute();
            ChangeShowTime();
            ChangeshowInk();
            ChangeModePlay();
            ReadVolumn();
            SelectXml();
            ChangeShowFilm();
            NewLoaded();
            this.PlayerList.ContextMenu = getListMenu();  
        }

        /// <summary>
        /// 计时器响应事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Tim_Elapsed(object sender, ElapsedEventArgs e)
        {
            this.SliPlayerTime.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new DeleSetPosition(setPosition));
        }

        /// <summary>
        /// 打开播放器响应事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void MPPlayer_MediaOpened(object sender, EventArgs e)
        {
            if (this.MPPlayer.NaturalDuration.HasTimeSpan)
            {
                this.MaxLen = (int)Math.Round(this.MPPlayer.NaturalDuration.TimeSpan.TotalSeconds);
                this.SliPlayerTime.Maximum = this.MaxLen;
                this.SliPlayerTime.Minimum = 0;
                this.tbSeek.Text = "00:00:00";
            }
            VideoDrawing drawing = new VideoDrawing();
            Rect rect = new Rect(0.0, 0.0, this.MPPlayer.NaturalVideoWidth, this.MPPlayer.NaturalVideoHeight);
            drawing.Rect = rect;
            drawing.Player = this.MPPlayer;
            DrawingBrush brush = new DrawingBrush(drawing);
            this.InkCanvas_Player.Background = brush;
            NewOpenPlay();
        }

        /// <summary>
        /// 播放完成响应事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void MPPlayer_MediaEnded(object sender, EventArgs e)
        {
            this.SliPlayerTime.Value = 0;
            this.MPPlayer.Position = new TimeSpan(0, 0, 0);
            this.MPPlayer.Stop();
            this.MSStatus = MediaStatus.Pause;
            this.TSStatus = TimeStatus.FileTime;
            this.InkCanvas_Player.Background = Brushes.White;
            this.ChangeShowTime();
            this.ChangeShowPlay();
        }

        /// <summary>
        /// 改变播放器的显示Size
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Player_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(this.FileName))
            {
                if (this.FileName.Contains(".swf"))
                {
                    this.FlashFormHost.Width = Convert.ToInt32(this.InkCanvas_Player.ActualWidth);
                    this.FlashFormHost.Height = Convert.ToInt32(this.InkCanvas_Player.ActualHeight);
                }
            }
        }

        /// <summary>
        /// 点击屏幕播放\暂停
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void InkCanvas_Player_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (!string.IsNullOrEmpty(this.FileName))
                {
                    if (!this.FileName.Contains(".swf") && this.FileName != "Camera")
                    {
                        if (MSStatus == MediaStatus.Play)
                        {
                            MSStatus = MediaStatus.Pause;
                            this.Pause();
                        }
                        else
                        {
                            MSStatus = MediaStatus.Play;
                            this.Play();
                        }
                    }
                }
                ChangeShowPlay();
            }
        }

        /// <summary>
        /// 时间轴控制
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SliPlayerTime_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            try
            {
                if (!string.IsNullOrEmpty(this.FileName) && this.IsChangeValue)
                {
                    int PlayerTime = (int)Math.Round(e.NewValue);
                    if (this.FileName.Contains(".swf"))
                    {
                        this.FlashShock.GotoFrame(PlayerTime);
                    }
                    else
                    {
                        TimeSpan span = new TimeSpan(0, 0, PlayerTime);
                        this.MPPlayer.Position = span;
                    }
                }
            }
            catch (Exception ChangeEx)
            {
                System.Windows.MessageBox.Show(ChangeEx.ToString());
            }
        }

        /// <summary>
        /// 时间轴控制（按下）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SliPlayerTime_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            this.IsChangeValue = true;
        }

        /// <summary>
        /// 时间轴控制（松开）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SliPlayerTime_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            this.IsChangeValue = false;
        }

        /// <summary>
        /// 播放/暂停
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgPlayer_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (MSStatus == MediaStatus.Pause)
                {
                    MSStatus = MediaStatus.Play;
                    this.Play();
                }
                else
                {
                    MSStatus = MediaStatus.Pause;
                    this.Pause();
                }
                ChangeShowPlay();
            }
        }

        /// <summary>
        /// 停止播放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgStop_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (!string.IsNullOrEmpty(this.FileName))
                {
                    if (this.FileName.Contains(".swf"))
                    {
                        this.FlashShock.Dispose();
                        this.SliPlayerTime.Value = 0;
                        this.FileName = "";
                        MSStatus = MediaStatus.Pause;
                        this.InkCanvas_Player.Background = Brushes.White;
                    }
                    if (this.FileName == "Camera")
                    {
                        this.CameraPlayer.Dispose();
                        this.SliPlayerTime.Value = 0;
                        this.FileName = "";
                        MSStatus = MediaStatus.Pause;
                        this.InkCanvas_Camera.Background = Brushes.White;
                    }
                    else
                    {
                        this.MPPlayer.Close();
                        this.SliPlayerTime.Value = 0;
                        this.FileName = "";
                        MSStatus = MediaStatus.Pause;
                        TSStatus = TimeStatus.SystemTime;
                        this.InkCanvas_Player.Background = Brushes.White;
                        this.PCink = PlayCamera.inkMediaPlay;
                        ChangeshowInk();
                        this.tbText.Text = "";
                        ChangeShowPlay();
                        ChangeShowTime();
                    }
                } 
            }
        }

        /// <summary>
        /// 上一部
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgPre_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                PrePlayer();
                SavePlayTime();
                PlayNextPre();
            }
        }

        /// <summary>
        /// 下一部
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgNext_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                NextPlayer();
                SavePlayTime();
                PlayNextPre();
            }
        }

        /// <summary>
        /// 打开文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgOpen_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.OpenFilePlay();
            }
        }

        /// <summary>
        /// 静音控制
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgMute_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (SSStatus == SoundStatus.Sound)
                {
                    SSStatus = SoundStatus.Mute;
                    sound = this.MPPlayer.Volume;
                    this.MPPlayer.Volume = 0.0;
                }
                else
                {
                    SSStatus = SoundStatus.Sound;
                    this.MPPlayer.Volume = sound;
                }
                ChangeShowMute();
            }
        }

        /// <summary>
        /// 声音轴控制
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SldVolumn_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (SSStatus == SoundStatus.Sound)
            {
                this.MPPlayer.Volume = e.NewValue;
            }
            else
            {
                sound = e.NewValue;
            }
        }

        /// <summary>
        /// 截图
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgScreen_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (string.IsNullOrEmpty(this.FileName))
                {
                    return;
                }
                else if (this.FileName.Contains(".swf"))
                {
                    PlayerCommon.SaveFlashImage(this.FlashShock);
                }
                else if (this.FileName == "Camera")
                {
                    PlayerCommon.SaveCameraImage(this);
                }
                else if (this.MPPlayer.HasVideo)
                {
                    PlayerCommon.SaveVideoImage(this);
                } 
            }
        }

        /// <summary>
        /// 设计截图保存位置和格式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgScreen_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Screen screen = new Screen();
            screen.ShowDialog();
        }

        /// <summary>
        /// 摄像头设备选择
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgCamera_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Camera camera = new Camera(this);
                this.MPPlayer.Pause();
                MSStatus = MediaStatus.Pause;
                ChangeShowPlay();
                camera.ShowDialog(); 
            }
        }

        /// <summary>
        /// 菜单栏--打开URL
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenURL url = new OpenURL(this);
            url.ShowDialog();
        }

        /// <summary>
        /// 菜单栏--退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WinClose_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            SaveVolumn();
            SavePlayTime();
            this.Close();
            this.MPPlayer.Close();
            this.MSStatus = MediaStatus.Pause;
            this.FileName = string.Empty;
            this.InkCanvas_Player.Children.Clear();
            this.InkCanvas_Camera.Children.Clear();
            if (this.CameraPlayer != null)
            {
                this.CameraPlayer.Dispose();
                this.CameraPlayer = null;
            }
        }

        /// <summary>
        /// 点击选择皮肤颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Colors_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Controls.MenuItem menu = (System.Windows.Controls.MenuItem)sender;
            ColorsTag = menu.Tag.ToString();
            SaveColors();
            ChangeColors();
        }

        /// <summary>
        /// ListView控件鼠标双击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ListView_PreviewMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int index = ListView.SelectedIndex;
            if (index != -1)
            {
                this.memoryPlay = true;
                ListPlay();
            } 
        }

        /// <summary>
        /// 选择背景图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeImages_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Controls.MenuItem menu = (System.Windows.Controls.MenuItem)sender;
            ImagesTag = menu.Tag.ToString();
            switch (ImagesTag)
            {
                case"ACustom":
                    ChangeShowFilms();
                    break;
                case"DefaultImages":
                    ImagesChanges = "gd.jpg";
                    ImageChangeFilm();
                    ChangeShowFilm();
                    break;
                case"SpringGreen":
                    ImagesChanges = "Spring.jpg";
                    ImageChangeFilm();
                    ChangeShowFilm();
                    break;
                case"SummerBlue":
                    ImagesChanges = "Summer.jpg";
                    ImageChangeFilm();
                    ChangeShowFilm();
                    break;
                case"AutumnYellow":
                    ImagesChanges = "Autumn.jpg";
                    ImageChangeFilm();
                    ChangeShowFilm();
                    break;
                case"WinterWhite":
                    ImagesChanges = "Winter.jpg";
                    ImageChangeFilm();
                    ChangeShowFilm();
                    break;
            }
        }

        /// <summary>
        /// 取消背景图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelImages_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            CancelFilms();
            ChangeShowFilm();
        }

        /// <summary>
        /// 添加文件（按钮）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgAddFile_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                AddFiles();
            }
        }

        /// <summary>
        /// 删除文件（按钮）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImgRemoveFile_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                RemoveFiles();
            }
        }

        /// <summary>
        /// 选择播放模式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeMode_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Controls.MenuItem menu = (System.Windows.Controls.MenuItem)sender;
            ModePlayTag = menu.Tag.ToString();
            SaveMode();
            ChangeModePlay();
        }

        /// <summary>
        /// 关于播放器
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AboutPlayer_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }

        /// <summary>
        /// 播放器默认大小
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DefaultSize_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.WindowState = System.Windows.WindowState.Normal;
            this.Width = 750;
            this.Height = 500;
        }

        /// <summary>
        /// 播放列表鼠标右击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void itemDelete_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.MenuItem item = (System.Windows.Controls.MenuItem)sender;
            string stringName = item.Tag.ToString();
            switch (stringName)
            {
                case "ListPlay":
                    int play = ListView.SelectedIndex;
                    if (play != -1)
                    {
                        this.memoryPlay = false;
                        ListPlay();
                    }
                    break;

                case "Delete":
                    RemoveFiles();
                    break;

                case "DeleteAll":
                    RemoveAllFiles();
                    break;
            }
        }

        /// <summary>
        /// 获取播放列表鼠标右击下拉菜单
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public System.Windows.Controls.ContextMenu getListMenu()
        {
            System.Windows.Controls.MenuItem itemDelete;
            System.Windows.Controls.ContextMenu contextMenu = new System.Windows.Controls.ContextMenu();

            itemDelete = new System.Windows.Controls.MenuItem();
            itemDelete.Tag = "ListPlay";
            itemDelete.Header = "记 忆 播 放";
            itemDelete.Click+=new RoutedEventHandler(itemDelete_Click);
            contextMenu.Items.Add(itemDelete);

            itemDelete = new System.Windows.Controls.MenuItem();
            itemDelete.Tag = "Delete";
            itemDelete.Header = "  删   除  ";
            itemDelete.Click += new RoutedEventHandler(itemDelete_Click);
            contextMenu.Items.Add(itemDelete);

            itemDelete = new System.Windows.Controls.MenuItem();
            itemDelete.Tag = "DeleteAll";
            itemDelete.Header = "删 除 所 有";
            itemDelete.Click += new RoutedEventHandler(itemDelete_Click);
            contextMenu.Items.Add(itemDelete);

            return contextMenu;
        }

        /// <summary>
        /// 窗体初始化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NewLoaded()
        {
            try
            {
                if (this.InitPlayerPath != null && !String.IsNullOrEmpty(this.InitPlayerPath.ToString().Trim()))
                {
                    string[] paths = this.InitPlayerPath.ToString().Split('\\');
                    this.FileName = paths[paths.Length - 1];

                    if (this.FileName.Contains(".swf"))
                    {
                        PlayerCommon.OpenFlash(this, this, InitPlayerPath.ToString());
                        this.MPPlayer.Close();
                        this.SliPlayerTime.Value = 0;
                        this.SliPlayerTime.Maximum = this.FlashShock.TotalFrames;
                        this.tbSeek.Text = this.FlashShock.TotalFrames.ToString();
                        this.Play();
                    }
                    else
                    {
                        this.Open(this.InitPlayerPath.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        /// <summary>
        /// 计算播放的时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void setPosition()
        {
            if (string.IsNullOrEmpty(this.FileName))
            {
                return;
            }
            if (this.FileName.Contains(".swf"))
            {
                this.SliPlayerTime.Value = this.FlashShock.FrameNum;
                this.tbSeek.Text = string.Format("{0}/{1}", this.FlashShock.FrameNum, this.FlashShock.TotalFrames);
                TSStatus = TimeStatus.FileTime;
                ChangeShowTime();
            }
            else
            {
                int num = ((this.MPPlayer.Position.Hours * 0xe10) + (this.MPPlayer.Position.Minutes * 60)) + this.MPPlayer.Position.Seconds;
                //double dbNum = this.MPPlayer.Position.Ticks / 10000000;
                //int intNum = (int)Math.Round(dbNum);
                string str = SetTime(this.MPPlayer.Position.Hours) + ":" + SetTime(this.MPPlayer.Position.Minutes) + ":" + SetTime(this.MPPlayer.Position.Seconds);
                this.tbSeek.Text = string.Format("{0}/{1}", SetTime(this.MPPlayer.Position.Hours) + ":" + SetTime(this.MPPlayer.Position.Minutes) + ":" + SetTime(this.MPPlayer.Position.Seconds), this.MediaCountTime);
                this.SliPlayerTime.Value = num;
                string next = SetTime(this.MPPlayer.Position.Hours) + ":" + SetTime(this.MPPlayer.Position.Minutes) + ":" + SetTime(this.MPPlayer.Position.Seconds);
                if (next.Equals(this.MediaCountTime))
                {
                    NextPlayer();
                    PlayNextPre();
                }
                ChangeShowPlay();
            }
        }

        /// <summary>
        /// 显示底片背景
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeShowFilm()
        {
            ImageBrush image = new ImageBrush();
            FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
            if (fileInfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                XmlNode childNodes = xmlDoc.SelectSingleNode("Images");
                XmlElement element = (XmlElement)childNodes; ;
                string images = element["Path"].InnerText;
                if (!string.IsNullOrEmpty(images))
                {
                    FileInfo finfo = new FileInfo("" + images + "");
                    if (finfo.Exists)
                    {
                        image.ImageSource = new BitmapImage(new Uri("" + images + "", UriKind.Relative));
                    }
                }
            }
            this.stackPanel.Background = image;
            this.stackPanel.Opacity = 0.7;
        }

        /// <summary>
        /// 选择底部图片（自带（保存））
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ImageChangeFilm()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\Images\" + "" + ImagesChanges + "");
            if (finfo.Exists)
            {
                FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                if (fileInfo.Exists)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                    XmlNode childNode = xmlDoc.SelectSingleNode("Images");
                    XmlElement element = (XmlElement)childNode;
                    element["Path"].InnerText = AppDomain.CurrentDomain.BaseDirectory + @"\Images\" + "" + ImagesChanges + "";
                    xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                }
            }
        }

        /// <summary>
        /// 显示底片背景（自定义）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeShowFilms()
        {
            Microsoft.Win32.OpenFileDialog OpenFile = new Microsoft.Win32.OpenFileDialog();
            string from = "Images Files(*.jpg;*.bmp;*.png)|*.jpg;*.bmp;*.png";
            OpenFile.FileName = "";
            OpenFile.Filter = from;
            OpenFile.Multiselect = false;
            OpenFile.ShowDialog();
            string fileName = OpenFile.FileName;
            if (!string.IsNullOrEmpty(fileName))
            {
                ImageBrush image = new ImageBrush();
                image.ImageSource = new BitmapImage(new Uri("" + fileName + "", UriKind.Relative));
                this.stackPanel.Background = image;
                this.stackPanel.Opacity = 0.7;
                FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                if (finfo.Exists)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                    XmlNode childNodes = xmlDoc.SelectSingleNode("Images");
                    XmlElement element = (XmlElement)childNodes; ;
                    element["Path"].InnerText = fileName;
                    xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                }
            }
        }

        /// <summary>
        /// 取消底片背景（删除XML文件对应信息）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelFilms()
        {
            FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
            if (fileInfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
                XmlNode childNodes = xmlDoc.SelectSingleNode("Images");
                XmlElement element = (XmlElement)childNodes;
                element["Path"].InnerText = "";
                xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Images.xml");
            }
        }

        /// <summary>
        /// 显示与隐藏播放、暂停按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeShowPlay()
        {
            if (!string.IsNullOrEmpty(this.FileName))
            {
                switch (MSStatus)
                {
                    case MediaStatus.Play:
                        this.ImgPlayer.Visibility = Visibility.Hidden;
                        this.ImgPause.Visibility = Visibility.Visible;
                        break;
                    case MediaStatus.Pause:
                        this.ImgPause.Visibility = Visibility.Hidden;
                        this.ImgPlayer.Visibility = Visibility.Visible;
                        break;
                }
            }
        }

        /// <summary>
        /// 列表播放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ListPlay()
        {
            string name = ListView.SelectedItem.ToString();
            FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
            if (fileInfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                string lists = xmlNode.InnerText;
                if (!string.IsNullOrEmpty(lists))
                {
                    XmlNodeList nodes = xmlNode.SelectNodes("List");
                    foreach (XmlNode node in nodes)
                    {
                        XmlElement element = (XmlElement)node;
                        if (name.Equals(element["Name"].InnerText))
                        {
                            changes = element["Path"].InnerText;
                        }
                    }
                }
            }
            SavePlayTime();

            this.PCink = PlayCamera.inkMediaPlay;
            ChangeshowInk();
            Microsoft.Win32.OpenFileDialog OpenFile = new Microsoft.Win32.OpenFileDialog();
            OpenFile.FileName = changes;
            this.FileName = OpenFile.SafeFileName;

            FileInfo finfo = new FileInfo("" + changes + "");
            if (finfo.Exists)
            {
                this.InkCanvas_Player.Background = Brushes.White;
                this.InkCanvas_Player.Children.Clear();
                //清空flash播放文件
                if (this.FlashShock != null)
                {
                    this.FlashShock.Dispose();
                }

                //播放flash文件判断
                if (this.FileName.Contains(".swf"))
                {
                    PlayerCommon.OpenFlash(this, changes);
                    this.MPPlayer.Close();
                    this.SliPlayerTime.Value = 0;
                    this.SliPlayerTime.Maximum = this.FlashShock.TotalFrames;
                    this.tbSeek.Text = this.FlashShock.TotalFrames.ToString();
                    this.Pause();
                    return;
                }
                else
                {
                    this.Pause();
                    //播放视频文件
                    if (this.MPPlayer.HasVideo)
                    {
                        this.MPPlayer.Close();
                    }
                    this.Open(changes);
                    //系统时间与播放时间切换
                    TSStatus = TimeStatus.FileTime;
                    ChangeShowTime();
                    SelectPlayTime();
                    double time = 0;
                    int intTime = 0;
                    if (this.memoryPlay)
                    {
                        this.ListNodeTime = "";
                    }
                    if (!string.IsNullOrEmpty(this.ListNodeTime))
                    {
                        time = double.Parse(this.ListNodeTime);
                    }
                    intTime = (int)Math.Round(time);
                    TimeSpan span = new TimeSpan(0, 0, intTime);
                    this.MPPlayer.Position = span;
                    this.MPPlayer.Play();
                }
            }
            else
            {
                this.MPPlayer.Close();
                this.SliPlayerTime.Value = 0;
                MSStatus = MediaStatus.Pause;
                TSStatus = TimeStatus.SystemTime;
                this.InkCanvas_Player.Background = Brushes.White;
                this.PCink = PlayCamera.inkMediaPlay;
                ChangeshowInk();
                this.tbText.Text = "";
                ChangeShowPlay();
                ChangeShowTime();
            } 
        }

        /// <summary>
        /// 保存播放时间（记忆播放）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SavePlayTime()
        {
            if (!string.IsNullOrEmpty(this.FileName))
            {
                FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                if (fileInfo.Exists)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                    XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                    string lists = xmlNode.InnerText;
                    if (!string.IsNullOrEmpty(lists))
                    {
                        XmlNodeList nodes = xmlNode.SelectNodes("List");
                        foreach (XmlNode node in nodes)
                        {
                            XmlElement element = (XmlElement)node;
                            if (this.FileName.Equals(element["Name"].InnerText))
                            {
                                if ((this.FileName.Contains(".mp3")) | (this.FileName.Contains(".wma")) | (this.FileName.Contains(".mp4")) | (this.FileName.Contains(".wav")) | (this.FileName.Contains(".mid")) | (this.FileName.Contains(".swf")))
                                {
                                    this.ListNodeTime = "";
                                    element["Time"].InnerText = "";
                                    xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                                }
                                else
                                {
                                    element["Time"].InnerText = this.MPPlayer.Position.TotalSeconds.ToString();
                                    xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 获取播放时间（记忆播放）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SelectPlayTime()
        {
            if (!string.IsNullOrEmpty(this.FileName))
            {
                if ((this.FileName.Contains(".mp3")) | (this.FileName.Contains(".wma")) | (this.FileName.Contains(".mp4")) | (this.FileName.Contains(".wav")) | (this.FileName.Contains(".mid")) | (this.FileName.Contains(".swf")))
                {
                    this.ListNodeTime = "";
                }
                else
                {
                    FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                    if (fileInfo.Exists)
                    {
                        XmlDocument xmlDoc = new XmlDocument();
                        xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                        XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                        string lists = xmlNode.InnerText;
                        if (!string.IsNullOrEmpty(lists))
                        {
                            XmlNodeList nodes = xmlNode.SelectNodes("List");
                            foreach (XmlNode node in nodes)
                            {
                                XmlElement element = (XmlElement)node;
                                if (this.FileName.Equals(element["Name"].InnerText))
                                {
                                    this.ListNodeTime = element["Time"].InnerText;
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 开始播放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Play()
        {
            try
            {
                if (string.IsNullOrEmpty(this.FileName))
                {
                    return;
                }
                if (this.FileName.Contains(".swf"))
                {
                    this.FlashShock.Play();
                }
                else if (this.CameraPlayer != null)
                {
                    if (this.FileName == "Camera")
                    {
                        this.CameraPlayer.Continue();
                    }
                    if (this.FileName != "Camera" && !this.FileName.Contains(".swf"))
                    {
                        this.MPPlayer.Play();
                    }
                }
                else
                {
                    this.MPPlayer.Play();
                }
                this.Timing.Start();
            }
            catch (Exception PlayEx)
            {
                throw PlayEx;
            }
        }

        /// <summary>
        /// 暂停播放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Pause()
        {
            try
            {
                if (string.IsNullOrEmpty(this.FileName))
                {
                    return;
                }
                if (this.FileName.Contains(".swf"))
                {
                    this.FlashShock.StopPlay();
                    this.Timing.Start();
                }
                else if (this.CameraPlayer != null)
                {
                    this.CameraPlayer.Pause();
                    if (this.FileName != "Camera")
                    {
                        this.MPPlayer.Pause();
                        this.Timing.Stop();
                    }
                }
                else
                {
                    this.MPPlayer.Pause();
                    this.Timing.Stop();
                }
                this.MSStatus = MediaStatus.Pause;
            }
            catch (Exception PauseEx)
            {
                throw PauseEx;
            }
        }

        /// <summary>
        /// 重新打开播放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NewOpenPlay()
        {
            this.Play();
            ChangeshowInk();
            if ((this.FileName.Contains(".mp3")) | (this.FileName.Contains(".wma")) | (this.FileName.Contains(".mp4")) | (this.FileName.Contains(".wav")) | (this.FileName.Contains(".mid")))
            {
                this.InkCanvas_Player.Background = Brushes.White;
                this.InkCanvas_Camera.Visibility = Visibility.Hidden;
                this.InkCanvas_Player.Visibility = Visibility.Hidden;
            }
            this.MediaCountTime = this.MPPlayer.NaturalDuration.ToString().Split('.')[0];
            this.MPPlayer.Volume = this.SldVolumn.Value;
            this.MSStatus = MediaStatus.Play;
            ChangeShowPlay();

            //提取文件时间长度，并且保存在List.xml文件中
            this.ListNodeLength = this.MPPlayer.NaturalDuration.ToString().Split('.')[0];
            if (!string.IsNullOrEmpty(this.ListNodeName) && !string.IsNullOrEmpty(this.ListNodePath) && !string.IsNullOrEmpty(this.ListNodeLength))
            {
                if (!IsExist())
                {
                    AddList();
                }
                SelectXml();
            }
            //显示播放文件名
            this.tbText.Text = this.FileName;
        }

        /// <summary>
        /// 打开播放的文件内容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Open(string fn)
        {
            try
            {
                if (this.MPPlayer.HasVideo)
                {
                    this.MPPlayer.Close();
                }
                this.MPPlayer.Open(new Uri(fn, UriKind.Absolute));

                VideoDrawing drawing = new VideoDrawing();
                Rect rect = new Rect(0.0, 0.0, this.InkCanvas_Player.ActualWidth, this.InkCanvas_Player.ActualHeight);
                drawing.Rect = rect;
                drawing.Player = this.MPPlayer;
                DrawingBrush brush = new DrawingBrush(drawing);
                this.InkCanvas_Player.Background = brush;
                NewOpenPlay();
            }
            catch (Exception OpenEx)
            {
                throw OpenEx;
            }
        }

        /// <summary>
        /// 打开播放的文件内容（URL方式）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OpenUrl(string fn)
        {
            if (this.MPPlayer.HasVideo)
            {
                this.MPPlayer.Close();
            }
            this.MPPlayer.Open(new Uri(fn, UriKind.Absolute));

            VideoDrawing drawing = new VideoDrawing();
            Rect rect = new Rect(0.0, 0.0, this.InkCanvas_Player.ActualWidth, this.InkCanvas_Player.ActualHeight);
            drawing.Rect = rect;
            drawing.Player = this.MPPlayer;
            DrawingBrush brush = new DrawingBrush(drawing);
            this.InkCanvas_Player.Background = brush;
        }

        /// <summary>
        /// 显示与隐藏声音\静音按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeShowMute()
        {
            switch (SSStatus)
            {
                case SoundStatus.Sound:
                    this.ImgMute2.Visibility = Visibility.Hidden;
                    this.ImgMute.Visibility = Visibility.Visible;
                    break;
                case SoundStatus.Mute:
                    this.ImgMute.Visibility = Visibility.Hidden;
                    this.ImgMute2.Visibility = Visibility.Visible;
                    break;
            }
        }

        /// <summary>
        /// 显示与隐藏视频\摄像屏幕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeshowInk()
        {
            switch (PCink)
            {
                case PlayCamera.inkMediaPlay:
                    this.InkCanvas_Camera.Visibility = Visibility.Hidden;
                    this.InkCanvas_Player.Visibility = Visibility.Visible;
                    break;
                case PlayCamera.inkCameraPlay:
                    this.InkCanvas_Player.Visibility = Visibility.Hidden;
                    this.InkCanvas_Camera.Visibility = Visibility.Visible;
                    break;
            }
        }

        /// <summary>
        /// 显示时间重置方法
        /// </summary>
        /// <param name="currentTime">当前的时间值</param>
        /// <param>格式为：00 的时间</param>
        private string SetTime(int currentTime)
        {
            return currentTime < 10 ? "0" + currentTime.ToString() : currentTime.ToString();
        }

        /// <summary>
        /// 显示与隐藏系统时间\文件时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeShowTime()
        {
            switch (TSStatus)
            {
                case TimeStatus.SystemTime:
                    this.tbSeek.Visibility = Visibility.Hidden;
                    this.tbTime.Visibility = Visibility.Visible;
                    break;
                case TimeStatus.FileTime:
                    this.tbTime.Visibility = Visibility.Hidden;
                    this.tbSeek.Visibility = Visibility.Visible;
                    break;
            }
        }

        /// <summary>
        /// 执行摄像头摄像功能（确定）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void NewCamera(int SelectedIndex)
        {
            if (SelectedIndex >= 0)
            {
                //退出视频播放
                this.InkCanvas_Player.Background = Brushes.White;
                this.InkCanvas_Player.Children.Clear();
                this.MPPlayer.Close();
                this.SliPlayerTime.Value = 0;
                this.FileName = "";
                MSStatus = MediaStatus.Pause;
                TSStatus = TimeStatus.SystemTime;
                ChangeShowPlay();
                ChangeShowTime();
                this.PCink = PlayCamera.inkCameraPlay;
                ChangeshowInk();

                //清空flash播放文件
                if (this.FlashShock != null)
                {
                    this.FlashShock.Dispose();
                }

                this.FileName = "Camera";
                if (this.CameraPlayer != null && this.CameraPlayer.DeviceNum == SelectedIndex)
                {
                    this.CameraPlayer.Continue();
                    this.InkCanvas_Camera.Background = new VisualBrush(this.CameraPlayer);
                }
                else
                {
                    this.CameraPlayer = new CapPlayer(SelectedIndex);
                    this.InkCanvas_Camera.Background = new VisualBrush(this.CameraPlayer);
                    RotateTransform rotTranform = new RotateTransform(180);
                    this.CameraPlayer.RenderTransformOrigin = new Point(0.5, 0.5);
                    this.CameraPlayer.RenderTransform = rotTranform;
                }
                this.MSStatus = MediaStatus.Play;
                ChangeShowPlay();
            }
            else
            {
                this.MPPlayer.Play();
                MSStatus = MediaStatus.Play;
                this.Play();
                ChangeShowPlay();
            }
        }

        /// <summary>
        /// 执行摄像头摄像功能（取消）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void CancelCamera()
        {
            this.MPPlayer.Play();
            MSStatus = MediaStatus.Play;
            this.Play();
            ChangeShowPlay();
        }

        /// <summary>
        /// 打开文件播放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OpenFilePlay()
        {
            this.PCink = PlayCamera.inkMediaPlay;
            //ChangeshowInk();
            Microsoft.Win32.OpenFileDialog OpenFile = new Microsoft.Win32.OpenFileDialog();
            string from = "Media Files(*.wmv;*.avi;*.asf;*.mpg;*.rmvb)|*.wmv;*.avi;*.asf;*.mpg;*.rmvb;*.mp3;*.wma;*.wav;*.mid|Flash Files(*.swf)|*.swf|All Files(*.*)|*.*";
            OpenFile.FileName = "";
            OpenFile.Filter = from;
            OpenFile.Multiselect = false;
            OpenFile.ShowDialog();
            string fileName = OpenFile.FileName;
            if (OpenFile.CheckPathExists && !string.IsNullOrEmpty(fileName))
            {
                try
                {
                    SavePlayTime();
                    this.FileName = OpenFile.SafeFileName;
                    this.InkCanvas_Player.Background = Brushes.White;
                    this.InkCanvas_Player.Children.Clear();
                    //清空flash播放文件
                    if (this.FlashShock != null)
                    {
                        this.FlashShock.Dispose();
                    }

                    //播放flash文件判断
                    if (this.FileName.Contains(".swf"))
                    {
                        PlayerCommon.OpenFlash(this, fileName);
                        this.MPPlayer.Close();
                        this.SliPlayerTime.Value = 0;
                        this.SliPlayerTime.Maximum = this.FlashShock.TotalFrames;
                        this.tbSeek.Text = this.FlashShock.TotalFrames.ToString();
                        this.Pause();
                        //return;
                    }
                    else
                    {
                        this.Pause();
                        //播放视频文件
                        if (this.MPPlayer.HasVideo)
                        {
                            this.MPPlayer.Close();
                        }
                        this.Open(fileName);
                        //系统时间与播放时间切换
                        TSStatus = TimeStatus.FileTime;
                        ChangeShowTime();
                        this.MPPlayer.Play();
                    }
                    
                    //提取文件名称和路径
                    this.ListNodeName = OpenFile.SafeFileName;
                    this.ListNodePath = OpenFile.FileName;
                }
                catch (Exception OpenFileEx)
                {
                    throw OpenFileEx;
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(fileName))
                {
                    this.MPPlayer.Pause();
                    this.MPPlayer.Play();
                    MSStatus = MediaStatus.Play;
                    this.Play();
                    ChangeShowPlay();
                    if ((this.FileName.Contains(".mp3")) | (this.FileName.Contains(".wma")) | (this.FileName.Contains(".mp4")) | (this.FileName.Contains(".wav")) | (this.FileName.Contains(".mid")))
                    {
                        this.InkCanvas_Player.Background = Brushes.White;
                        this.InkCanvas_Camera.Visibility = Visibility.Hidden;
                        this.InkCanvas_Player.Visibility = Visibility.Hidden;
                    } 
                }
            }
        }

        /// <summary>
        /// 打开路径文件播放
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OpenPathPlay()
        {
            this.PCink = PlayCamera.inkMediaPlay;
            ChangeshowInk();
            SavePlayTime();
            FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "OpenURL.xml");
            if (fileInfo.Exists)
            {
                XmlDocument ScreenXml = new XmlDocument();
                ScreenXml.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "OpenURL.xml");
                XmlNode ScreenNode = ScreenXml.SelectSingleNode("OpenURL");
                XmlElement element = (XmlElement)ScreenNode;
                string fileName = element["Path"].InnerText;
                Microsoft.Win32.OpenFileDialog OpenFile = new Microsoft.Win32.OpenFileDialog();
                OpenFile.FileName = fileName;
                this.FileName = OpenFile.SafeFileName;
                if (fileName.Length >= 3)
                {
                    string sub = fileName.Substring(1, 2);
                    if (sub == ":\\")
                    {
                        this.InkCanvas_Player.Background = Brushes.White;
                        this.InkCanvas_Player.Children.Clear();
                        //清空flash播放文件
                        if (this.FlashShock != null)
                        {
                            this.FlashShock.Dispose();
                        }

                        //播放flash文件判断
                        if (this.FileName.Contains(".swf"))
                        {
                            PlayerCommon.OpenFlash(this, fileName);
                            this.MPPlayer.Close();
                            this.SliPlayerTime.Value = 0;
                            this.SliPlayerTime.Maximum = this.FlashShock.TotalFrames;
                            this.tbSeek.Text = this.FlashShock.TotalFrames.ToString();
                            this.Pause();
                            return;
                        }
                        else
                        {
                            this.Pause();
                            //播放视频文件
                            if (this.MPPlayer.HasVideo)
                            {
                                this.MPPlayer.Close();
                            }
                            this.Open(fileName);
                            FileInfo finfo = new FileInfo("" + fileName + "");
                            if (finfo.Exists)
                            {
                                this.ListNodePath = fileName;
                                this.ListNodeName = this.FileName;
                            }
                            //系统时间与播放时间切换
                            TSStatus = TimeStatus.FileTime;
                            ChangeShowTime();
                            this.MPPlayer.Play();
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("输入的路径格式错误！");
                    }

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("输入的路径格式错误！");
                }
            }
        }

        /// <summary>
        /// 保存选择的皮肤颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveColors()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Colors.xml");
            if (finfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Colors.xml");
                XmlNode childNodes = xmlDoc.SelectSingleNode("Colors");
                XmlElement element = (XmlElement)childNodes; ;
                element["Change"].InnerText = ColorsTag;
                xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Colors.xml");
            }
        }

        /// <summary>
        /// 皮肤颜色选择
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ChangeColors()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Colors.xml");
            if (finfo.Exists)
            {
                XmlDocument ScreenXml = new XmlDocument();
                ScreenXml.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Colors.xml");
                XmlNode ScreenNode = ScreenXml.SelectSingleNode("Colors");
                XmlElement element = (XmlElement)ScreenNode;
                ColorsTag = element["Change"].InnerText;
                switch (ColorsTag)
                {
                    case "Custom":
                        System.Windows.Forms.ColorDialog selectColor = new System.Windows.Forms.ColorDialog();
                        if (selectColor.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            this.GridPlayer.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xff, selectColor.Color.R, selectColor.Color.G, selectColor.Color.B));
                            this.MenuMain.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xff, selectColor.Color.R, selectColor.Color.G, selectColor.Color.B));
                            this.GridTitle.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xff, selectColor.Color.R, selectColor.Color.G, selectColor.Color.B));
                            this.Head.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xff, selectColor.Color.R, selectColor.Color.G, selectColor.Color.B));
                            ColorsTag = System.Windows.Media.Color.FromArgb(0xff, selectColor.Color.R, selectColor.Color.G, selectColor.Color.B).ToString();

                            XmlDocument xmlDoc = new XmlDocument();
                            xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Colors.xml");
                            XmlNode childNodes = xmlDoc.SelectSingleNode("Colors");
                            XmlElement ColorElement = (XmlElement)childNodes; ;
                            ColorElement["Change"].InnerText = ColorsTag;
                            xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Colors.xml");
                        }
                        break;
                    case "LightBlue":
                        this.GridPlayer.Background = Brushes.LightBlue;
                        this.MenuMain.Background = Brushes.LightBlue;
                        this.GridTitle.Background = Brushes.LightBlue;
                        this.Head.Background = Brushes.LightBlue;
                        break;
                    case "Beige":
                        this.GridPlayer.Background = Brushes.Beige;
                        this.MenuMain.Background = Brushes.Beige;
                        this.GridTitle.Background = Brushes.Beige;
                        this.Head.Background = Brushes.Beige;
                        break;
                    case "SkyBlue":
                        this.GridPlayer.Background = Brushes.SkyBlue;
                        this.MenuMain.Background = Brushes.SkyBlue;
                        this.GridTitle.Background = Brushes.SkyBlue;
                        this.Head.Background = Brushes.SkyBlue;
                        break;
                    case "Wheat":
                        this.GridPlayer.Background = Brushes.Wheat;
                        this.MenuMain.Background = Brushes.Wheat;
                        this.GridTitle.Background = Brushes.Wheat;
                        this.Head.Background = Brushes.Wheat;
                        break;
                    case "Violet":
                        this.GridPlayer.Background = Brushes.Violet;
                        this.MenuMain.Background = Brushes.Violet;
                        this.GridTitle.Background = Brushes.Violet;
                        this.Head.Background = Brushes.Violet;
                        break;
                    case "SlateBlue":
                        this.GridPlayer.Background = Brushes.SlateBlue;
                        this.MenuMain.Background = Brushes.SlateBlue;
                        this.GridTitle.Background = Brushes.SlateBlue;
                        this.Head.Background = Brushes.SlateBlue;
                        break;
                    case "MediumPurple":
                        this.GridPlayer.Background = Brushes.MediumPurple;
                        this.MenuMain.Background = Brushes.MediumPurple;
                        this.GridTitle.Background = Brushes.MediumPurple;
                        this.Head.Background = Brushes.MediumPurple;
                        break;
                    case "LightGreen":
                        this.GridPlayer.Background = Brushes.LightGreen;
                        this.MenuMain.Background = Brushes.LightGreen;
                        this.GridTitle.Background = Brushes.LightGreen;
                        this.Head.Background = Brushes.LightGreen;
                        break;
                    case "HotPink":
                        this.GridPlayer.Background = Brushes.HotPink;
                        this.MenuMain.Background = Brushes.HotPink;
                        this.GridTitle.Background = Brushes.HotPink;
                        this.Head.Background = Brushes.HotPink;
                        break;
                    case "LightSlateGray":
                        this.GridPlayer.Background = Brushes.LightSlateGray;
                        this.MenuMain.Background = Brushes.LightSlateGray;
                        this.GridTitle.Background = Brushes.LightSlateGray;
                        this.Head.Background = Brushes.LightSlateGray;
                        break;
                    case "Gold":
                        this.GridPlayer.Background = Brushes.Gold;
                        this.MenuMain.Background = Brushes.Gold;
                        this.GridTitle.Background = Brushes.Gold;
                        this.Head.Background = Brushes.Gold;
                        break;
                    case "DarkViolet":
                        this.GridPlayer.Background = Brushes.DarkViolet;
                        this.MenuMain.Background = Brushes.DarkViolet;
                        this.GridTitle.Background = Brushes.DarkViolet;
                        this.Head.Background = Brushes.DarkViolet;
                        break;
                    case "Crimson":
                        this.GridPlayer.Background = Brushes.Crimson;
                        this.MenuMain.Background = Brushes.Crimson;
                        this.GridTitle.Background = Brushes.Crimson;
                        this.Head.Background = Brushes.Crimson;
                        break;
                    default:
                        BrushConverter brushConverter = new BrushConverter();
                        this.GridPlayer.Background = (Brush)brushConverter.ConvertFromString(ColorsTag);
                        this.MenuMain.Background = (Brush)brushConverter.ConvertFromString(ColorsTag);
                        this.GridTitle.Background = (Brush)brushConverter.ConvertFromString(ColorsTag);
                        this.Head.Background = (Brush)brushConverter.ConvertFromString(ColorsTag);
                        break;
                }
            }
        }

        /// <summary>
        /// 保存选择的播放模式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveMode()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Mode.xml");
            if (finfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Mode.xml");
                XmlNode childNode = xmlDoc.SelectSingleNode("Mode");
                XmlElement element = (XmlElement)childNode;
                element["Change"].InnerText = ModePlayTag;
                xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Mode.xml");
            }
        }

        /// <summary>
        /// 播放模式选择
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ChangeModePlay()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Mode.xml");
            if (finfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Mode.xml");
                XmlNode childNode = xmlDoc.SelectSingleNode("Mode");
                XmlElement element = (XmlElement)childNode;
                ModePlayTag = element["Change"].InnerText;
            }
        }

        /// <summary>
        /// 读取声音大小信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReadVolumn()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Volumn.xml");
            if (finfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Volumn.xml");
                XmlNode childNodes = xmlDoc.SelectSingleNode("Volumn");
                XmlElement element = (XmlElement)childNodes;
                this.SldVolumn.Value = double.Parse(element["Size"].InnerText);
            }
        }

        /// <summary>
        /// 保存声音大小信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveVolumn()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Volumn.xml");
            if (finfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Volumn.xml");
                XmlNode childNodes = xmlDoc.SelectSingleNode("Volumn");
                XmlElement element = (XmlElement)childNodes;
                element["Size"].InnerText = this.SldVolumn.Value.ToString().Trim();
                xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "Volumn.xml");
            }
        }

        /// <summary>
        /// 添加保存List.xml信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddList()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
            if (finfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");

                XmlNode ListNode = xmlDoc.CreateElement("List");

                XmlNode NameNode = xmlDoc.CreateElement("Name");
                XmlText NameText = xmlDoc.CreateTextNode(this.ListNodeName);
                NameNode.AppendChild(NameText);

                XmlNode PathNode = xmlDoc.CreateElement("Path");
                XmlText PathText = xmlDoc.CreateTextNode(this.ListNodePath);
                PathNode.AppendChild(PathText);

                XmlNode LengthNode = xmlDoc.CreateElement("Length");
                XmlText LengthText = xmlDoc.CreateTextNode(this.ListNodeLength);
                LengthNode.AppendChild(LengthText);

                XmlNode TimeNode = xmlDoc.CreateElement("Time");
                XmlText TimeText = xmlDoc.CreateTextNode(this.ListNodeTime);
                TimeNode.AppendChild(TimeText);

                ListNode.AppendChild(NameNode);
                ListNode.AppendChild(PathNode);
                ListNode.AppendChild(LengthNode);
                ListNode.AppendChild(TimeNode);

                xmlNode.AppendChild(ListNode);

                xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
            }
        }

        /// <summary>
        /// 判定文件是否存在于List.xml文件中
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public bool IsExist()
        {
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
            if (finfo.Exists)
            {
                XPathDocument xPath = new XPathDocument(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                XPathNavigator navigator = xPath.CreateNavigator();
                XPathNodeIterator iterator = navigator.Select("/Lists/List[Name='" + this.ListNodeName + "']");
                if (iterator.Count == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 查询List.xml文件，并于播放列表显示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SelectXml()
        {
            ListView.Items.Clear();
            FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
            if (finfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                string lists = xmlNode.InnerText;
                if (!string.IsNullOrEmpty(lists))
                {
                    XmlNodeList nodes = xmlNode.SelectNodes("List");
                    foreach (XmlNode node in nodes)
                    {
                        XmlElement element = (XmlElement)node;
                        string[] subItems = new string[3];
                        subItems[0] = element["Name"].InnerText;
                        subItems[1] = element["Path"].InnerText;
                        System.Windows.Forms.ListViewItem listViewItem = new System.Windows.Forms.ListViewItem(subItems);
                        string listViewItems = listViewItem.ToString().Substring(15, listViewItem.ToString().Length - 16);
                        ListView.Items.Add(listViewItems);
                    }
                }
            }
        }

        /// <summary>
        /// 定义播放下一部
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NextPlayer()
        {
            FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
            if (fileInfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                string lists = xmlNode.InnerText;
                if (!string.IsNullOrEmpty(lists) && !string.IsNullOrEmpty(this.FileName))
                {
                    XmlNodeList nodes = xmlNode.SelectNodes("List");
                    int i = 0;
                    foreach (XmlNode node in nodes)
                    {
                        XmlElement element = (XmlElement)node;
                        i++;
                        if (this.FileName.Equals(element["Name"].InnerText))
                        {
                            number = i;
                        }

                    }
                    string name = "";
                    if (ModePlayTag.Equals("RepeatPlay"))
                    {
                        name = ListView.Items[number - 1].ToString();
                    }
                    else
                        if (ModePlayTag.Equals("OrderPlay"))
                        {
                            if (ListView.Items.Count == number)
                            {
                                name = "";
                            }
                            else
                            {
                                name = ListView.Items[number].ToString();
                            }
                        }
                    else
                            if (ModePlayTag.Equals("LoopPlay"))
                            {
                                if (ListView.Items.Count == number)
                                {
                                    name = ListView.Items[0].ToString();
                                }
                                else
                                {
                                    name = ListView.Items[number].ToString();
                                }
                            }
                    if (name == "")
                    {
                        changes = "";
                    }
                    else
                    {
                        foreach (XmlNode node in nodes)
                        {
                            XmlElement element = (XmlElement)node;
                            if (name.Equals(element["Name"].InnerText))
                            {
                                changes = element["Path"].InnerText;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 定义播放上一部
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PrePlayer()
        {
            FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
            if (fileInfo.Exists)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                string lists = xmlNode.InnerText;
                if (!string.IsNullOrEmpty(lists) && !string.IsNullOrEmpty(this.FileName))
                {
                    XmlNodeList nodes = xmlNode.SelectNodes("List");
                    int i = 0;
                    foreach (XmlNode node in nodes)
                    {
                        XmlElement element = (XmlElement)node;
                        i++;
                        if (this.FileName.Equals(element["Name"].InnerText))
                        {
                            number = i;
                        }

                    }
                    string name = "";
                    if (ModePlayTag.Equals("RepeatPlay"))
                    {
                        name = ListView.Items[number - 1].ToString();
                    }
                    else
                        if (ModePlayTag.Equals("OrderPlay"))
                        {
                            if (number == 1)
                            {
                                name = "";
                            }
                            else
                            {
                                name = ListView.Items[number - 2].ToString();
                            }
                        }
                        else
                            if (ModePlayTag.Equals("LoopPlay"))
                            {
                                if (number == 1)
                                {
                                    name = ListView.Items[ListView.Items.Count - 1].ToString();
                                }
                                else
                                {
                                    name = ListView.Items[number - 2].ToString();
                                }
                            }
                    if (name == "")
                    {
                        changes = "";
                    }
                    else
                    {
                        foreach (XmlNode node in nodes)
                        {
                            XmlElement element = (XmlElement)node;
                            if (name.Equals(element["Name"].InnerText))
                            {
                                changes = element["Path"].InnerText;
                            }
                        } 
                    }
                }
            }
        }

        /// <summary>
        /// 实现播放（上一部，下一部）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PlayNextPre()
        {
            this.PCink = PlayCamera.inkMediaPlay;
            ChangeshowInk();
            Microsoft.Win32.OpenFileDialog OpenFile = new Microsoft.Win32.OpenFileDialog();
            OpenFile.FileName = changes;
            this.FileName = OpenFile.SafeFileName;

            if (string.IsNullOrEmpty(changes))
            {
                this.MPPlayer.Close();
                this.SliPlayerTime.Value = 0;
                MSStatus = MediaStatus.Pause;
                TSStatus = TimeStatus.SystemTime;
                this.InkCanvas_Player.Background = Brushes.White;
                this.PCink = PlayCamera.inkMediaPlay;
                ChangeshowInk();
                this.tbText.Text = "";
                ChangeShowPlay();
                ChangeShowTime();
            }
            else
            {
                FileInfo finfo = new FileInfo("" + changes + "");
                if (finfo.Exists)
                {
                    this.InkCanvas_Player.Background = Brushes.White;
                    this.InkCanvas_Player.Children.Clear();
                    //清空flash播放文件
                    if (this.FlashShock != null)
                    {
                        this.FlashShock.Dispose();
                    }

                    //播放flash文件判断
                    if (this.FileName.Contains(".swf"))
                    {
                        PlayerCommon.OpenFlash(this, changes);
                        this.MPPlayer.Close();
                        this.SliPlayerTime.Value = 0;
                        this.SliPlayerTime.Maximum = this.FlashShock.TotalFrames;
                        this.tbSeek.Text = this.FlashShock.TotalFrames.ToString();
                        this.Pause();
                        return;
                    }
                    else
                    {
                        this.Pause();
                        //播放视频文件
                        if (this.MPPlayer.HasVideo)
                        {
                            this.MPPlayer.Close();
                        }
                        this.Open(changes);
                        //系统时间与播放时间切换
                        TSStatus = TimeStatus.FileTime;
                        ChangeShowTime();
                        this.MPPlayer.Play();
                    }
                }
                else
                {
                    this.MPPlayer.Close();
                    this.SliPlayerTime.Value = 0;
                    MSStatus = MediaStatus.Pause;
                    TSStatus = TimeStatus.SystemTime;
                    this.InkCanvas_Player.Background = Brushes.White;
                    this.PCink = PlayCamera.inkMediaPlay;
                    ChangeshowInk();
                    this.tbText.Text = "";
                    ChangeShowPlay();
                    ChangeShowTime(); 
                }
            }
        }
        
        /// <summary>
        /// 定义添加文件（按钮）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddFiles()
        {
            Microsoft.Win32.OpenFileDialog OpenFile = new Microsoft.Win32.OpenFileDialog();
            string from = "Media Files(*.wmv;*.avi;*.asf;*.mpg;*.rmvb)|*.wmv;*.avi;*.asf;*.mpg;*.rmvb;*.mp3;*.wma;*.wav;*.mid|Flash Files(*.swf)|*.swf|All Files(*.*)|*.*";
            OpenFile.FileName = "";
            OpenFile.Filter = from;
            OpenFile.Multiselect = false;
            OpenFile.ShowDialog();
            if (OpenFile.CheckFileExists && !string.IsNullOrEmpty(OpenFile.FileName))
            {
                this.ListNodeName = OpenFile.SafeFileName;
                this.ListNodePath = OpenFile.FileName;
                if (!IsExist())
                {
                    AddList();
                }
                SelectXml();
            }
        }

        /// <summary>
        /// 定义删除文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RemoveFiles()
        {
            int index = ListView.SelectedIndex;
            if (index != -1)
            {
                string name = ListView.SelectedItem.ToString();
                FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                if (finfo.Exists)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                    XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                    XmlNodeList nodeList = xmlNode.SelectNodes("List");
                    foreach (XmlNode node in nodeList)
                    {
                        if (node.SelectSingleNode("Name").InnerText.Equals(name))
                        {
                            xmlNode.RemoveChild(node);
                            xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                            SelectXml();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 定义删除所有文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RemoveAllFiles()
        {
            int indexAll = ListView.SelectedIndex;
            if (indexAll != -1)
            {
                FileInfo finfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                if (finfo.Exists)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                    XmlNode xmlNode = xmlDoc.SelectSingleNode("Lists");
                    XmlNodeList nodeList = xmlNode.SelectNodes("List");
                    foreach (XmlNode node in nodeList)
                    {
                        xmlNode.RemoveChild(node);
                        xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + @"\XML\" + "List.xml");
                        SelectXml();
                    }
                }
            }
        }

        
    }
}
