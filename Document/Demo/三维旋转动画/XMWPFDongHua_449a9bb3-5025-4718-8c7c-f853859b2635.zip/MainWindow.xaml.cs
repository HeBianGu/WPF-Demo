﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

using System.Windows.Threading;

using System.Windows.Media.Media3D;

namespace WpfCylinder
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Point3D lookat = new Point3D(0, 0, 0);

        public MainWindow()
        {
            InitializeComponent();
        }

        public DirectionalLight positionLight(Point3D position)
        {
            DirectionalLight directionalLight = new DirectionalLight();
            directionalLight.Color = Colors.Gray;
            directionalLight.Direction = new Point3D(0, 0, 0) - position;
            return directionalLight;
        }

        public DirectionalLight leftLight()
        {
            return positionLight(new Point3D(-WpfScene.sceneSize, WpfScene.sceneSize / 2, 0.0));
        }


        public PerspectiveCamera camera()
        {
            PerspectiveCamera perspectiveCamera = new PerspectiveCamera();

            perspectiveCamera.Position = new Point3D(-WpfScene.sceneSize, WpfScene.sceneSize / 2, WpfScene.sceneSize);

            perspectiveCamera.LookDirection = new Vector3D(lookat.X - perspectiveCamera.Position.X,
                                                           lookat.Y - perspectiveCamera.Position.Y,
                                                           lookat.Z - perspectiveCamera.Position.Z);

            perspectiveCamera.FieldOfView = 60;

            return perspectiveCamera;
        }


        private void Viewport3D_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is Viewport3D)
            {
                Viewport3D viewport = (Viewport3D)sender;

                Cylinder cylinder = new Cylinder(
                    new Point3D(0, WpfScene.sceneSize / 4, WpfScene.sceneSize / 5), 
                    40, WpfScene.sceneSize / 8, 
                    WpfScene.sceneSize / 8, 
                    WpfScene.sceneSize / 6);

                Cylinder cylinder2 = new Cylinder(
                    new Point3D(-WpfScene.sceneSize / 2, WpfScene.sceneSize / 4,  0), 
                    40, WpfScene.sceneSize / 8,
                    WpfScene.sceneSize / 8, 
                    WpfScene.sceneSize / 6);


                WpfCircle circle = new WpfCircle(55, 
                    new Point3D(-WpfScene.sceneSize / 2, WpfScene.sceneSize / 6, WpfScene.sceneSize / 2), WpfScene.sceneSize / 15);

                WpfCircle circle2 = new WpfCircle(55, 
                    new Point3D(0, WpfScene.sceneSize / 6, WpfScene.sceneSize / 2), WpfScene.sceneSize / 15);


                GeometryModel3D cylinderModel = cylinder.CreateModel(Colors.AliceBlue, true, true);

                GeometryModel3D cylinderModel2 = cylinder2.CreateModel(Colors.AliceBlue, true, false);

                GeometryModel3D circleModel = circle.createModel(Colors.Aqua, false);
                GeometryModel3D circleModel2 = circle2.createModelTwoSided(Colors.Aqua, false);


                double floorThickness = WpfScene.sceneSize / 100;
                GeometryModel3D floorModel = WpfCube.CreateCubeModel(
                    new Point3D(-WpfScene.sceneSize / 2,
                                -floorThickness,
                                -WpfScene.sceneSize / 2),
                    WpfScene.sceneSize, floorThickness, WpfScene.sceneSize, Colors.Tan);

                Model3DGroup groupScene = new Model3DGroup();

                groupScene.Children.Add(floorModel);
                
                groupScene.Children.Add(cylinderModel);
                groupScene.Children.Add(cylinderModel2);
                groupScene.Children.Add(circleModel);
                groupScene.Children.Add(circleModel2);


                groupScene.Children.Add(leftLight());
                groupScene.Children.Add(new AmbientLight(Colors.Gray));

                viewport.Camera = camera();

                ModelVisual3D visual = new ModelVisual3D();

                visual.Content = groupScene;

                viewport.Children.Add(visual);

                turnModel(cylinder.getCenter(), cylinderModel, 0, 360, 13, true);
                turnModel(cylinder2.getCenter(), cylinderModel2, 0, 360, 13, true);

                turnModel(circle.getCenter(), circleModel, 0, 360, 8, true);
                turnModel(circle2.getCenter(), circleModel2, 0, 360, 8, true);
            }
        }

        public void turnModel(Point3D center, GeometryModel3D model, double beginAngle, double endAngle, double seconds, bool forever)
        {
            Vector3D vector = new Vector3D(0, 1, 0);

            AxisAngleRotation3D rotation = new AxisAngleRotation3D(vector, 0.0);

            DoubleAnimation doubleAnimation = new DoubleAnimation(beginAngle, endAngle, durationTS(seconds));

            if (forever)
            {
                doubleAnimation.RepeatBehavior = RepeatBehavior.Forever;
            }

            doubleAnimation.BeginTime = durationTS(0.0);

            RotateTransform3D rotateTransform = new RotateTransform3D(rotation, center);

            model.Transform = rotateTransform;

            rotation.BeginAnimation(AxisAngleRotation3D.AngleProperty, doubleAnimation);
        }


        private int durationM(double seconds)
        {
            int milliseconds = (int)(seconds * 1000);
            return milliseconds;
        }

        public TimeSpan durationTS(double seconds)
        {
            TimeSpan ts = new TimeSpan(0, 0, 0, 0, durationM(seconds));
            return ts;
        }





        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is MainWindow)
            {
                Rect r = SystemParameters.WorkArea;

                MainWindow window = (MainWindow)sender;

                window.Width = r.Width;
                window.Height = r.Height;
                window.Left = 0;
                window.Top = 0;
            }
        }



    }
}
