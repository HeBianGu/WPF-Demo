﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfCylinder
{
    class WpfScene
    {
        public static double sceneSize = 20;
    }
}
