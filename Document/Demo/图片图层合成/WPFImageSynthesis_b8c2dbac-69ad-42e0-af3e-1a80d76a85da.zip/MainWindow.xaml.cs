﻿using System;
using System.Windows;

using System.IO;
using GDI = System.Drawing;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WpfImageOverlay
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.btn1.Click += new RoutedEventHandler(btn1_Click);
            this.btn2.Click += new RoutedEventHandler(btn2_Click);
        }
        // 下载于www.51aspx.com
        void btn1_Click(object sender, RoutedEventArgs e)
        {
            this.imgPreview.Source = MakePicture(@"bg.jpg", @"tiger.png", " I'm Tiger !");
        }

        void btn2_Click(object sender, RoutedEventArgs e)
        {
            this.imgPreview.Source = MakePictureGDI(@"bg.jpg", @"lion.png", "I'm Lion !");
        }

        private BitmapSource MakePicture(string bgImagePath, string headerImagePath, string signature)
        {
            // 下载于www.51aspx.com
            //获取背景图
            BitmapSource bgImage = new BitmapImage(new Uri(bgImagePath, UriKind.Relative));
            //获取头像
            BitmapSource headerImage = new BitmapImage(new Uri(headerImagePath, UriKind.Relative));

            //创建一个RenderTargetBitmap 对象，将WPF中的Visual对象输出
            RenderTargetBitmap composeImage = new RenderTargetBitmap(bgImage.PixelWidth, bgImage.PixelHeight, bgImage.DpiX, bgImage.DpiY, PixelFormats.Default);

            FormattedText signatureTxt = new FormattedText(signature,
                                                   System.Globalization.CultureInfo.CurrentCulture,
                                                   System.Windows.FlowDirection.LeftToRight,
                                                   new Typeface(System.Windows.SystemFonts.MessageFontFamily, FontStyles.Normal, FontWeights.Normal, FontStretches.Normal),
                                                   50,
                                                   System.Windows.Media.Brushes.White);



            DrawingVisual drawingVisual = new DrawingVisual();
            DrawingContext drawingContext = drawingVisual.RenderOpen();
            drawingContext.DrawImage(bgImage, new Rect(0, 0, bgImage.Width, bgImage.Height));

            //计算头像的位置
            double x = (bgImage.Width / 2 - headerImage.Width) / 2;
            double y = (bgImage.Height - headerImage.Height) / 2 - 100;
            drawingContext.DrawImage(headerImage, new Rect(x, y, headerImage.Width, headerImage.Height));

            //计算签名的位置
            double x2 = (bgImage.Width/2 - signatureTxt.Width) / 2;
            double y2 = y + headerImage.Height + 20;
            drawingContext.DrawText(signatureTxt, new System.Windows.Point(x2, y2));
            drawingContext.Close();
            composeImage.Render(drawingVisual);

            //定义一个JPG编码器
            JpegBitmapEncoder bitmapEncoder = new JpegBitmapEncoder();
            //加入第一帧
            bitmapEncoder.Frames.Add(BitmapFrame.Create(composeImage));
            // 下载于www.51aspx.com
            //保存至文件（不会修改源文件，将修改后的图片保存至程序目录下）
            string savePath = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase + @"\合成.jpg";
            bitmapEncoder.Save(File.OpenWrite(Path.GetFileName(savePath)));
            return composeImage;
        }

        private BitmapSource MakePictureGDI(string bgImagePath, string headerImagePath, string signature)
        {
            GDI.Image bgImage = GDI.Bitmap.FromFile(bgImagePath);
            GDI.Image headerImage = GDI.Bitmap.FromFile(headerImagePath);
           
            //新建一个画板，画板的大小和底图一致
            System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(bgImage.Width, bgImage.Height);
            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bitmap);
            //设置高质量插值法
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(System.Drawing.Color.Transparent);

            //先在画板上面画底图
            g.DrawImage(bgImage, new GDI.Rectangle(0, 0, bitmap.Width, bitmap.Height));

            //再在画板上画头像
            int x = (bgImage.Width / 2 - headerImage.Width) / 2;
            int y = (bgImage.Height - headerImage.Height) / 2 - 100;
            g.DrawImage(headerImage, new GDI.Rectangle(x, y, headerImage.Width, headerImage.Height),
                                     new GDI.Rectangle(0, 0, headerImage.Width, headerImage.Height),
                                     GDI.GraphicsUnit.Pixel);



            //在画板上写文字
            using (GDI.Font f = new GDI.Font("Arial", 20, GDI.FontStyle.Bold))
            {
                using (GDI.Brush b = new GDI.SolidBrush(GDI.Color.White))
                {
                    float fontWidth = g.MeasureString(signature, f).Width;
                    float x2 = (bgImage.Width / 2 - fontWidth) / 2;
                    float y2 = y + headerImage.Height + 20;
                    g.DrawString(signature, f, b, x2, y2);
                }
            }
            // 下载于www.51aspx.com
            try
            {
                string savePath = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase + @"\GDI+合成.jpg";
                bitmap.Save(savePath, System.Drawing.Imaging.ImageFormat.Jpeg);
                return ToBitmapSource(bitmap);
            }
            catch (System.Exception e)
            {
                throw e;
            }
            finally
            {
                bgImage.Dispose();
                headerImage.Dispose();
                g.Dispose();
            }
        }

        #region GDI+ Image 转化成 BitmapSource
        [System.Runtime.InteropServices.DllImport("gdi32")]
        static extern int DeleteObject(IntPtr o);
        public BitmapSource ToBitmapSource(GDI.Bitmap bitmap)
        {
            IntPtr ip = bitmap.GetHbitmap();

            BitmapSource bitmapSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                ip, IntPtr.Zero, System.Windows.Int32Rect.Empty,
                System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions());
            DeleteObject(ip);//释放对象
            return bitmapSource;
        }
        #endregion
    }
}
