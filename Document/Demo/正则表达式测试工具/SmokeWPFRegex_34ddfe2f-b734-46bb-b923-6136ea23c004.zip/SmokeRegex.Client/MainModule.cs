﻿using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmokeRegex.Client
{
    public class MainModule : IModule
    {
        private IUnityContainer UnityContainer { get; set; }

        public MainModule(IUnityContainer unityContainer)
        {
            this.UnityContainer = unityContainer;
        }

        public void Initialize()
        {
            var regionManager = this.UnityContainer.Resolve<IRegionManager>();

            var mainView = this.UnityContainer.Resolve<Views.Main>();
            regionManager.AddToRegion("Main", mainView);
        }
    }
}
