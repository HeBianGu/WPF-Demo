﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmokeRegex.Client.Consts
{
    public class WindowNames
    {
        public static readonly string DownloadHtml = "DownloadHtml";

        public static readonly string Replace = "Replace";

        public static readonly string Help = "Help";

        public static readonly string About = "About";

        public static readonly string AddCustomPattern = "AddCustomPattern";
    }
}
