﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmokeRegex.Client.Events
{
    public class ReplaceEvent
    {
        public string ReplaceString { get; set; }

        public ReplaceEvent(string replaceString)
        {
            this.ReplaceString = replaceString;
        }
    }
}
