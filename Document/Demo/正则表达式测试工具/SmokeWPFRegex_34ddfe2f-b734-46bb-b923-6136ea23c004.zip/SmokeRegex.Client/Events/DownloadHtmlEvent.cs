﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmokeRegex.Client.Events
{
    public class DownloadHtmlEvent
    {
        public DownloadHtmlEvent(string html)
        {
            this.Html = html;
        }
        public string Html { get; set; }
    }
}
