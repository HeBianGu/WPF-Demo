﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmokeRegex.Client.Models
{
    /// <summary>
    /// 表达式信息
    /// </summary>
    public class PatternInfo
    {
        /// <summary>
        /// 显示的友好名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 表达式
        /// </summary>
        public string Pattern { get; set; }
    }
}
