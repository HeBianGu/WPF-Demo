﻿using Microsoft.Practices.Prism.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmokeRegex.Client.ViewModels
{
    public class AboutViewModel : Base.WindowViewModelBase
    {
        public AboutViewModel()
            : base(Consts.WindowNames.About)
        {

        }

        private DelegateCommand<string> _openLinkCommand;

        public DelegateCommand<string> OpenLinkCommand
        {
            get
            {
                if (_openLinkCommand == null)
                {
                    _openLinkCommand = new DelegateCommand<string>(this.OpenLink);
                }
                return _openLinkCommand;
            }
        }

        private void OpenLink(string parameter)
        {
            System.Diagnostics.Process.Start(parameter);
        }

    }
}
