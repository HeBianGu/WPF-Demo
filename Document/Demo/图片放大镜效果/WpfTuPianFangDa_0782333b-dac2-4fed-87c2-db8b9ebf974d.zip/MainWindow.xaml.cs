﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfZoom
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 半透明矩形框移动
        /// </summary>        
        private void MoveRect_MouseMove(object sender, MouseEventArgs e)
        {
            FrameworkElement element = sender as FrameworkElement;

            //计算鼠标在X轴的移动距离
            double deltaV = e.GetPosition(MoveRect).Y - MoveRect.Height / 2;
            //计算鼠标在Y轴的移动距离
            double deltaH = e.GetPosition(MoveRect).X - MoveRect.Width / 2; ;
            //得到图片Top新位置
            double newTop = deltaV + (double)MoveRect.GetValue(Canvas.TopProperty);
            //得到图片Left新位置
            double newLeft = deltaH + (double)MoveRect.GetValue(Canvas.LeftProperty);

            //边界的判断
            if (newLeft <= 0)
            {
                newLeft = 0;
            }

            //左侧图片框宽度 - 半透明矩形框宽度
            if (newLeft >= (this.SmallBox.Width - this.MoveRect.Width))
            {
                newLeft = this.SmallBox.Width - this.MoveRect.Width;
            }

            if (newTop <= 0)
            {
                newTop = 0;
            }

            //左侧图片框高度度 - 半透明矩形框高度度
            if (newTop >= this.SmallBox.Height - this.MoveRect.Height)
            {
                newTop = this.SmallBox.Height - this.MoveRect.Height;
            }
            MoveRect.SetValue(Canvas.TopProperty, newTop);
            MoveRect.SetValue(Canvas.LeftProperty, newLeft);
            #region
            //获取右侧大图框与透明矩形框的尺寸比率
            double n = this.BigBox.Width / this.MoveRect.Width;

            //获取半透明矩形框在左侧小图中的位置
            double left = (double)this.MoveRect.GetValue(Canvas.LeftProperty);
            double top = (double)this.MoveRect.GetValue(Canvas.TopProperty);

            //计算和设置原图在右侧大图框中的Canvas.Left 和 Canvas.Top
            bigImg.SetValue(Canvas.LeftProperty, -left * n);
            bigImg.SetValue(Canvas.TopProperty, -top * n);
            #endregion
        }

        private void SmallBox_MouseEnter(object sender, MouseEventArgs e)
        {
            BigBox.Visibility = Visibility.Visible;
        }

        private void SmallBox_MouseLeave(object sender, MouseEventArgs e)
        {
            BigBox.Visibility = Visibility.Hidden;
        }
    }
}
