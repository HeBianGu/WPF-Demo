﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf拖拽滑动效果
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        Point targetPoint;
        UIElement targetElement;
        double top;
        public MainWindow()
        {
            InitializeComponent();
            CreateNgEtry(ref NGEntry);
        }
        /// <summary>
        /// 创建按钮集合
        /// </summary>
        /// <param name="grid"></param>
        public void CreateNgEtry(ref Grid grid)
        {
            grid.Children.Clear();
            grid.RowDefinitions.Clear();
            grid.ColumnDefinitions.Clear();

            for (int i = 0; i < 6; i++)
            {
                //下载于www.51aspx.com
            }
            for (int i = 0; i < 18 + 1; i++)
            {
                grid.RowDefinitions.Add(new RowDefinition());
            }
            for (int i = 0; i < 18; i++)
            {
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                for (int j = 0; j < 6; j++)
                {
                    Button but = new Button();
                    but.Height = 80;
                    but.Width = 110;
                    but.FontSize = 16;
                    grid.Children.Add(but);
                    System.Windows.Controls.Grid.SetColumn(but, j);
                    System.Windows.Controls.Grid.SetRow(but, i);
                    but.Content = "Test" + i.ToString();

                }
            }

            //下载于www.51aspx.com

        }

        private void canvas_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            targetElement = Mouse.DirectlyOver as UIElement;
            if (targetElement != null)
            {
                targetPoint = e.GetPosition(NGEntry);
            }
        }

        private void canvas_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && targetElement != null)
            {
                var pCanvas = e.GetPosition(canvas);

                double gridtop = Convert.ToDouble(NGEntry.GetValue(Canvas.TopProperty));

                NGEntry.SetValue(Canvas.TopProperty, pCanvas.Y - targetPoint.Y);
                 
            }
        }

        private void canvas_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            double gridtop = Convert.ToDouble(NGEntry.GetValue(Canvas.TopProperty));
            double gridh = NGEntry.ActualHeight;
            double viewh = canvas.ActualHeight;
            if (gridtop > 0)
            {
                NGEntry.SetValue(Canvas.TopProperty, 0d);
            }
            if (viewh + (Math.Abs(gridtop)) > gridh)
            {
                NGEntry.SetValue(Canvas.TopProperty, viewh - gridh);
            }
        }
        //下载于www.51aspx.com
    }
}
